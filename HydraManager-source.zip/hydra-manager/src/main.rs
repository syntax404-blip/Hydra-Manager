use eframe::egui;
use futures_util::{StreamExt, future::try_join_all};
use reqwest::{
    Client, StatusCode,
    header::{ACCEPT_ENCODING, ACCEPT_RANGES, CONTENT_LENGTH, RANGE},
};
use serde::{Deserialize, Serialize};
use std::{
    path::{Path, PathBuf},
    sync::{
        Arc, Mutex,
        atomic::{AtomicU8, AtomicU64, Ordering},
    },
    time::{Duration, Instant},
};
use tokio::{
    fs::{self, OpenOptions},
    io::{AsyncSeekExt, AsyncWriteExt},
    runtime::Runtime,
    sync::Mutex as AsyncMutex,
    time::sleep,
};

#[derive(Clone, Copy)]
struct Palette {
    bg: egui::Color32,
    panel: egui::Color32,
    panel_hi: egui::Color32,
    line: egui::Color32,
    muted: egui::Color32,
    text: egui::Color32,
    blue: egui::Color32,
    amber: egui::Color32,
    red: egui::Color32,
    sidebar: egui::Color32,
    selected: egui::Color32,
    card_icon: egui::Color32,
    success: egui::Color32,
    failure: egui::Color32,
    accent: egui::Color32,
}

impl Palette {
    fn for_theme(theme: UiTheme) -> Self {
        match theme {
            UiTheme::Dark => Self {
                bg: egui::Color32::from_rgb(14, 19, 27),
                panel: egui::Color32::from_rgb(21, 28, 38),
                panel_hi: egui::Color32::from_rgb(28, 37, 49),
                line: egui::Color32::from_rgb(41, 52, 66),
                muted: egui::Color32::from_rgb(139, 153, 170),
                text: egui::Color32::from_rgb(236, 242, 248),
                blue: egui::Color32::from_rgb(99, 155, 255),
                amber: egui::Color32::from_rgb(250, 183, 91),
                red: egui::Color32::from_rgb(255, 111, 119),
                sidebar: egui::Color32::from_rgb(17, 23, 32),
                selected: egui::Color32::from_rgb(31, 54, 58),
                card_icon: egui::Color32::from_rgb(27, 40, 51),
                success: egui::Color32::from_rgb(29, 70, 63),
                failure: egui::Color32::from_rgb(77, 39, 45),
                accent: egui::Color32::WHITE,
            },
            UiTheme::Light => Self {
                bg: egui::Color32::from_rgb(243, 246, 249),
                panel: egui::Color32::WHITE,
                panel_hi: egui::Color32::from_rgb(231, 237, 243),
                line: egui::Color32::from_rgb(211, 220, 228),
                muted: egui::Color32::from_rgb(93, 108, 124),
                text: egui::Color32::from_rgb(26, 37, 49),
                blue: egui::Color32::from_rgb(43, 105, 190),
                amber: egui::Color32::from_rgb(150, 85, 0),
                red: egui::Color32::from_rgb(190, 48, 61),
                sidebar: egui::Color32::from_rgb(233, 238, 243),
                selected: egui::Color32::from_rgb(215, 235, 229),
                card_icon: egui::Color32::from_rgb(232, 238, 243),
                success: egui::Color32::from_rgb(217, 239, 231),
                failure: egui::Color32::from_rgb(250, 224, 226),
                accent: egui::Color32::from_rgb(20, 117, 101),
            },
            UiTheme::Monochrome => Self {
                bg: egui::Color32::from_rgb(8, 8, 8),
                panel: egui::Color32::from_rgb(20, 20, 20),
                panel_hi: egui::Color32::from_rgb(36, 36, 36),
                line: egui::Color32::from_rgb(58, 58, 58),
                muted: egui::Color32::from_rgb(174, 174, 174),
                text: egui::Color32::from_rgb(245, 245, 245),
                blue: egui::Color32::from_rgb(206, 206, 206),
                amber: egui::Color32::from_rgb(178, 178, 178),
                red: egui::Color32::from_rgb(132, 132, 132),
                sidebar: egui::Color32::from_rgb(13, 13, 13),
                selected: egui::Color32::from_rgb(43, 43, 43),
                card_icon: egui::Color32::from_rgb(31, 31, 31),
                success: egui::Color32::from_rgb(43, 43, 43),
                failure: egui::Color32::from_rgb(43, 43, 43),
                accent: egui::Color32::WHITE,
            },
        }
    }
}

fn palette(ui: &egui::Ui) -> Palette {
    palette_from_context(ui.ctx())
}

fn palette_from_context(ctx: &egui::Context) -> Palette {
    ctx.data(|data| data.get_temp::<Palette>(egui::Id::unique("hydra_palette")))
        .unwrap_or_else(|| Palette::for_theme(UiTheme::Dark))
}

fn with_alpha(color: egui::Color32, alpha: f32) -> egui::Color32 {
    egui::Color32::from_rgba_unmultiplied(
        color.r(),
        color.g(),
        color.b(),
        (255.0 * alpha.clamp(0.0, 1.0)) as u8,
    )
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
enum DownloadStatus {
    Queued,
    Downloading,
    Paused,
    Completed,
    Failed,
    Cancelled,
}

impl DownloadStatus {
    fn label(self, language: Language) -> &'static str {
        match self {
            Self::Queued => tr(language, Text::StatusQueued),
            Self::Downloading => tr(language, Text::StatusDownloading),
            Self::Paused => tr(language, Text::StatusPaused),
            Self::Completed => tr(language, Text::StatusCompleted),
            Self::Failed => tr(language, Text::StatusFailed),
            Self::Cancelled => tr(language, Text::StatusCancelled),
        }
    }

    fn color(self, accent: egui::Color32, palette: Palette) -> egui::Color32 {
        match self {
            Self::Queued => palette.amber,
            Self::Downloading => accent,
            Self::Paused => palette.blue,
            Self::Completed => accent,
            Self::Failed | Self::Cancelled => palette.red,
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
enum Priority {
    Low,
    Normal,
    High,
}

impl Priority {
    fn from_u8(value: u8) -> Self {
        match value {
            2 => Self::High,
            0 => Self::Low,
            _ => Self::Normal,
        }
    }

    fn value(self) -> u8 {
        match self {
            Self::Low => 0,
            Self::Normal => 1,
            Self::High => 2,
        }
    }

    fn label(self, language: Language) -> &'static str {
        match self {
            Self::Low => tr(language, Text::PriorityLow),
            Self::Normal => tr(language, Text::PriorityNormal),
            Self::High => tr(language, Text::PriorityHigh),
        }
    }
}

struct SpeedMeter {
    started: Instant,
    bytes: u64,
}

struct RateLimiter {
    next_slot: Mutex<Instant>,
}

impl RateLimiter {
    fn new() -> Self {
        Self {
            next_slot: Mutex::new(Instant::now()),
        }
    }

    async fn acquire(&self, bytes: usize, bytes_per_second: u64) {
        if bytes_per_second == 0 || bytes == 0 {
            return;
        }
        let wait = {
            let mut next = self.next_slot.lock().unwrap_or_else(|e| e.into_inner());
            let now = Instant::now();
            let start = (*next).max(now);
            let wait = start.saturating_duration_since(now);
            let slot = Duration::from_secs_f64(bytes as f64 / bytes_per_second as f64);
            *next = start + slot;
            wait
        };
        if !wait.is_zero() {
            sleep(wait).await;
        }
    }
}

struct DownloadTask {
    id: u64,
    language: Language,
    url: String,
    path: PathBuf,
    file_name: String,
    segments: usize,
    effective_segments: AtomicU8,
    speed_limit: AtomicU64,
    priority: AtomicU8,
    status: Mutex<DownloadStatus>,
    progress: AtomicU64,
    total: AtomicU64,
    speed: AtomicU64,
    control: AtomicU8,
    error: Mutex<Option<String>>,
    meter: Mutex<SpeedMeter>,
    limiter: RateLimiter,
}

impl DownloadTask {
    fn status(&self) -> DownloadStatus {
        *self.status.lock().unwrap_or_else(|e| e.into_inner())
    }

    fn set_status(&self, status: DownloadStatus) {
        *self.status.lock().unwrap_or_else(|e| e.into_inner()) = status;
    }

    fn record(&self, bytes: usize) {
        self.progress.fetch_add(bytes as u64, Ordering::Relaxed);
        let mut meter = self.meter.lock().unwrap_or_else(|e| e.into_inner());
        meter.bytes = meter.bytes.saturating_add(bytes as u64);
        let elapsed = meter.started.elapsed();
        if elapsed >= Duration::from_millis(300) {
            let rate = (meter.bytes as f64 / elapsed.as_secs_f64()) as u64;
            self.speed.store(rate, Ordering::Relaxed);
            meter.bytes = 0;
            meter.started = Instant::now();
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
enum View {
    All,
    Active,
    Queue,
    Finished,
    Settings,
}

#[derive(Clone, Copy)]
enum IconKind {
    Files,
    Activity,
    Queue,
    Check,
    Settings,
    Search,
    Download,
    Pause,
    Play,
    Close,
    Retry,
    Transfer,
    Copy,
    Reveal,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
enum AccentTheme {
    #[default]
    Mint,
    Sky,
    Violet,
    Amber,
}

impl AccentTheme {
    fn color(self) -> egui::Color32 {
        match self {
            Self::Mint => egui::Color32::from_rgb(59, 222, 190),
            Self::Sky => egui::Color32::from_rgb(94, 169, 255),
            Self::Violet => egui::Color32::from_rgb(178, 132, 255),
            Self::Amber => egui::Color32::from_rgb(250, 183, 91),
        }
    }

    fn label(self, language: Language) -> &'static str {
        match self {
            Self::Mint => tr(language, Text::AccentMint),
            Self::Sky => tr(language, Text::AccentSky),
            Self::Violet => tr(language, Text::AccentViolet),
            Self::Amber => tr(language, Text::AccentAmber),
        }
    }

    fn color_for(self, theme: UiTheme) -> egui::Color32 {
        match theme {
            UiTheme::Dark => self.color(),
            UiTheme::Monochrome => Palette::for_theme(theme).accent,
            UiTheme::Light => match self {
                Self::Mint => egui::Color32::from_rgb(20, 117, 101),
                Self::Sky => egui::Color32::from_rgb(43, 105, 190),
                Self::Violet => egui::Color32::from_rgb(111, 69, 173),
                Self::Amber => egui::Color32::from_rgb(150, 85, 0),
            },
        }
    }
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
enum UiTheme {
    #[default]
    Dark,
    Light,
    Monochrome,
}

impl UiTheme {
    fn label(self, language: Language) -> &'static str {
        match self {
            Self::Dark => tr(language, Text::ThemeDark),
            Self::Light => tr(language, Text::ThemeLight),
            Self::Monochrome => tr(language, Text::ThemeMonochrome),
        }
    }
}

#[repr(usize)]
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
enum Language {
    #[default]
    Spanish,
    English,
    German,
    French,
    Catalan,
    Russian,
}

impl Language {
    const ALL: [Self; 6] = [
        Self::Spanish,
        Self::English,
        Self::German,
        Self::French,
        Self::Catalan,
        Self::Russian,
    ];

    fn native_name(self) -> &'static str {
        match self {
            Self::Spanish => "Español",
            Self::English => "English",
            Self::German => "Deutsch",
            Self::French => "Français",
            Self::Catalan => "Català",
            Self::Russian => "Русский",
        }
    }
}

#[repr(usize)]
#[derive(Clone, Copy)]
enum Text {
    StatusQueued,
    StatusDownloading,
    StatusPaused,
    StatusCompleted,
    StatusFailed,
    StatusCancelled,
    PriorityLow,
    PriorityNormal,
    PriorityHigh,
    AccentMint,
    AccentSky,
    AccentViolet,
    AccentAmber,
    ThemeDark,
    ThemeLight,
    ThemeMonochrome,
    Language,
    Library,
    All,
    Active,
    Queue,
    Finished,
    Personalize,
    EngineReady,
    Downloads,
    DownloadQueue,
    Personalization,
    SettingsSubtitle,
    ManageSubtitle,
    BackToDownloads,
    NewDownload,
    SearchFile,
    Transfers,
    UpToConcurrent,
    Appearance,
    ThemeInterface,
    AccentColor,
    SelectedAccent,
    UiScale,
    Autosave,
    CompactMode,
    FluidAnimations,
    TransitionDuration,
    DefaultDownloads,
    Destination,
    ChooseFolder,
    SegmentsPerFile,
    PartsSuffix,
    Priority,
    UnlimitedSpeed,
    MaxPerFile,
    SimultaneousDownloads,
    ActiveSuffix,
    Files,
    InYourList,
    InProgress,
    ActiveTransfers,
    CompletedLabel,
    TotalSuffix,
    TotalSpeed,
    AllClear,
    AddLinkDescription,
    AddLink,
    Pause,
    Resume,
    Cancel,
    RemoveFromQueue,
    RetryQueue,
    NoLimit,
    MaxSpeed,
    PartOne,
    PartMany,
    Received,
    NewDownloadDescription,
    LinkLabel,
    PasteHint,
    FileName,
    DestinationFolder,
    TransferControls,
    DividePackages,
    RangeSupport,
    StartDownload,
    AddedToQueue,
    InvalidUrl,
    MissingFilename,
    FolderError,
    FileCreateError,
    FilePrepareError,
    NetworkError,
    RangeRejected,
    ReceiveError,
    WriteError,
    IncompleteSegment,
    UnexpectedSize,
    DownloadStartError,
    ServerResponse,
    DownloadCancelled,
    CopyLink,
    RevealInFinder,
    OpenFolderFailed,
    Count,
}

const TRANSLATIONS: &[[&str; 6]] = &[
    [
        "En cola",
        "Queued",
        "In Warteschlange",
        "En attente",
        "En cua",
        "В очереди",
    ],
    [
        "Descargando",
        "Downloading",
        "Wird geladen",
        "Téléchargement",
        "Baixant",
        "Загружается",
    ],
    [
        "Pausada",
        "Paused",
        "Pausiert",
        "En pause",
        "En pausa",
        "Приостановлена",
    ],
    [
        "Completada",
        "Completed",
        "Abgeschlossen",
        "Terminée",
        "Completada",
        "Завершена",
    ],
    [
        "Error",
        "Failed",
        "Fehlgeschlagen",
        "Échec",
        "Error",
        "Ошибка",
    ],
    [
        "Cancelada",
        "Cancelled",
        "Abgebrochen",
        "Annulée",
        "Cancel·lada",
        "Отменена",
    ],
    ["Baja", "Low", "Niedrig", "Basse", "Baixa", "Низкий"],
    ["Normal", "Normal", "Normal", "Normale", "Normal", "Обычный"],
    ["Alta", "High", "Hoch", "Haute", "Alta", "Высокий"],
    ["Menta", "Mint", "Minze", "Menthe", "Menta", "Мятный"],
    ["Celeste", "Sky", "Himmel", "Ciel", "Cel", "Небесный"],
    [
        "Violeta",
        "Violet",
        "Violett",
        "Violet",
        "Violeta",
        "Фиолетовый",
    ],
    ["Ámbar", "Amber", "Bernstein", "Ambre", "Ambre", "Янтарный"],
    ["Oscuro", "Dark", "Dunkel", "Sombre", "Fosc", "Тёмная"],
    ["Claro", "Light", "Hell", "Clair", "Clar", "Светлая"],
    [
        "Blanco y negro",
        "Black and white",
        "Schwarz-Weiß",
        "Noir et blanc",
        "Blanc i negre",
        "Чёрно-белая",
    ],
    ["Idioma", "Language", "Sprache", "Langue", "Idioma", "Язык"],
    [
        "BIBLIOTECA",
        "LIBRARY",
        "BIBLIOTHEK",
        "BIBLIOTHÈQUE",
        "BIBLIOTECA",
        "БИБЛИОТЕКА",
    ],
    ["Todas", "All", "Alle", "Toutes", "Totes", "Все"],
    [
        "Activas",
        "Active",
        "Aktiv",
        "Actives",
        "Actives",
        "Активные",
    ],
    [
        "En cola",
        "Queue",
        "Warteschlange",
        "En attente",
        "En cua",
        "Очередь",
    ],
    [
        "Finalizadas",
        "Finished",
        "Fertig",
        "Terminées",
        "Finalitzades",
        "Завершённые",
    ],
    [
        "Personalizar",
        "Customize",
        "Anpassen",
        "Personnaliser",
        "Personalitza",
        "Настройки",
    ],
    [
        "Listo para transferencias\nparalelas y por segmentos.",
        "Ready for parallel\nand segmented transfers.",
        "Bereit für parallele\nDownloads in Segmenten.",
        "Prêt pour les transferts\nparallèles et segmentés.",
        "A punt per a transferències\nparal·leles i per segments.",
        "Готов к параллельной\nзагрузке частями.",
    ],
    [
        "Descargas",
        "Downloads",
        "Downloads",
        "Téléchargements",
        "Baixades",
        "Загрузки",
    ],
    [
        "Cola de descargas",
        "Download queue",
        "Download-Warteschlange",
        "File d’attente",
        "Cua de baixades",
        "Очередь загрузок",
    ],
    [
        "Personalización",
        "Personalization",
        "Personalisierung",
        "Personnalisation",
        "Personalització",
        "Персонализация",
    ],
    [
        "Ajusta Hydra Manager a tu forma de trabajar.",
        "Make Hydra Manager work your way.",
        "Passe Hydra Manager an deinen Arbeitsstil an.",
        "Adaptez Hydra Manager à vos habitudes.",
        "Adapta Hydra Manager a la teva manera de treballar.",
        "Настройте Hydra Manager под себя.",
    ],
    [
        "Gestiona cada transferencia con precisión.",
        "Manage every transfer with precision.",
        "Verwalte jede Übertragung präzise.",
        "Gérez chaque transfert avec précision.",
        "Gestiona cada transferència amb precisió.",
        "Управляйте каждой загрузкой точно.",
    ],
    [
        "Volver a descargas",
        "Back to downloads",
        "Zurück zu Downloads",
        "Retour aux téléchargements",
        "Torna a les baixades",
        "К загрузкам",
    ],
    [
        "Nueva descarga",
        "New download",
        "Neuer Download",
        "Nouveau téléchargement",
        "Baixada nova",
        "Новая загрузка",
    ],
    [
        "Buscar archivo",
        "Search files",
        "Dateien suchen",
        "Rechercher un fichier",
        "Cerca fitxers",
        "Поиск файлов",
    ],
    [
        "TRANSFERENCIAS",
        "TRANSFERS",
        "ÜBERTRAGUNGEN",
        "TRANSFERTS",
        "TRANSFERÈNCIES",
        "ЗАГРУЗКИ",
    ],
    [
        "Hasta {} descargas simultáneas",
        "Up to {} simultaneous downloads",
        "Bis zu {} gleichzeitige Downloads",
        "Jusqu’à {} téléchargements simultanés",
        "Fins a {} baixades simultànies",
        "Одновременно: до {} загрузок",
    ],
    [
        "ASPECTO",
        "APPEARANCE",
        "DESIGN",
        "APPARENCE",
        "APARENÇA",
        "ВНЕШНИЙ ВИД",
    ],
    [
        "Tema de interfaz",
        "Interface theme",
        "Oberflächendesign",
        "Thème de l’interface",
        "Tema de la interfície",
        "Тема интерфейса",
    ],
    [
        "Color de acento",
        "Accent color",
        "Akzentfarbe",
        "Couleur d’accent",
        "Color d’accent",
        "Цвет акцента",
    ],
    [
        "Seleccionado: {}",
        "Selected: {}",
        "Ausgewählt: {}",
        "Sélectionné : {}",
        "Seleccionat: {}",
        "Выбрано: {}",
    ],
    [
        "Tamaño de la interfaz",
        "Interface size",
        "Oberflächengröße",
        "Taille de l’interface",
        "Mida de la interfície",
        "Масштаб интерфейса",
    ],
    [
        "Los cambios se guardan automáticamente.",
        "Changes are saved automatically.",
        "Änderungen werden automatisch gespeichert.",
        "Les changements sont enregistrés automatiquement.",
        "Els canvis es desen automàticament.",
        "Изменения сохраняются автоматически.",
    ],
    [
        "Interfaz compacta",
        "Compact interface",
        "Kompakte Oberfläche",
        "Interface compacte",
        "Interfície compacta",
        "Компактный интерфейс",
    ],
    [
        "Animaciones fluidas",
        "Smooth animations",
        "Flüssige Animationen",
        "Animations fluides",
        "Animacions fluides",
        "Плавная анимация",
    ],
    [
        "Duración de las transiciones",
        "Transition duration",
        "Übergangsdauer",
        "Durée des transitions",
        "Durada de les transicions",
        "Длительность переходов",
    ],
    [
        "DESCARGAS POR DEFECTO",
        "DOWNLOAD DEFAULTS",
        "DOWNLOAD-STANDARDS",
        "TÉLÉCHARGEMENTS PAR DÉFAUT",
        "BAIXADES PER DEFECTE",
        "ПАРАМЕТРЫ ЗАГРУЗКИ",
    ],
    [
        "Carpeta de destino",
        "Destination folder",
        "Zielordner",
        "Dossier de destination",
        "Carpeta de destinació",
        "Папка назначения",
    ],
    [
        "Elegir carpeta…",
        "Choose folder…",
        "Ordner auswählen…",
        "Choisir un dossier…",
        "Tria una carpeta…",
        "Выбрать папку…",
    ],
    [
        "Segmentos por archivo",
        "Segments per file",
        "Segmente pro Datei",
        "Segments par fichier",
        "Segments per fitxer",
        "Частей на файл",
    ],
    [
        " partes",
        " parts",
        " Teile",
        " parties",
        " parts",
        " частей",
    ],
    [
        "Prioridad",
        "Priority",
        "Priorität",
        "Priorité",
        "Prioritat",
        "Приоритет",
    ],
    [
        "Velocidad sin límite",
        "Unlimited speed",
        "Unbegrenzte Geschwindigkeit",
        "Vitesse illimitée",
        "Velocitat sense límit",
        "Без ограничения скорости",
    ],
    [
        "Máximo por archivo",
        "Per-file limit",
        "Limit pro Datei",
        "Limite par fichier",
        "Límit per fitxer",
        "Лимит на файл",
    ],
    [
        "Descargas simultáneas",
        "Simultaneous downloads",
        "Gleichzeitige Downloads",
        "Téléchargements simultanés",
        "Baixades simultànies",
        "Одновременные загрузки",
    ],
    [
        " activas",
        " active",
        " gleichzeitig",
        " actives",
        " actives",
        " одновременно",
    ],
    [
        "ARCHIVOS",
        "FILES",
        "DATEIEN",
        "FICHIERS",
        "FITXERS",
        "ФАЙЛЫ",
    ],
    [
        "en tu lista",
        "in your list",
        "in deiner Liste",
        "dans votre liste",
        "a la llista",
        "в списке",
    ],
    [
        "EN CURSO",
        "IN PROGRESS",
        "IN ARBEIT",
        "EN COURS",
        "EN CURS",
        "В ПРОЦЕССЕ",
    ],
    [
        "transferencias activas",
        "active transfers",
        "aktive Übertragungen",
        "transferts actifs",
        "transferències actives",
        "активных загрузок",
    ],
    [
        "COMPLETADAS",
        "COMPLETED",
        "ABGESCHLOSSEN",
        "TERMINÉS",
        "COMPLETADES",
        "ЗАВЕРШЕНО",
    ],
    [
        " total",
        " total",
        " gesamt",
        " au total",
        " en total",
        " всего",
    ],
    [
        "VELOCIDAD TOTAL",
        "TOTAL SPEED",
        "GESCHWINDIGKEIT",
        "VITESSE TOTALE",
        "VELOCITAT TOTAL",
        "ОБЩАЯ СКОРОСТЬ",
    ],
    [
        "Todo despejado",
        "All clear",
        "Alles erledigt",
        "Tout est prêt",
        "Tot a punt",
        "Пока ничего нет",
    ],
    [
        "Añade un enlace para iniciar tu próxima descarga.",
        "Add a link to start your next download.",
        "Füge einen Link hinzu, um den nächsten Download zu starten.",
        "Ajoutez un lien pour lancer votre prochain téléchargement.",
        "Afegeix un enllaç per iniciar la baixada següent.",
        "Добавьте ссылку, чтобы начать загрузку.",
    ],
    [
        "Añadir enlace",
        "Add link",
        "Link hinzufügen",
        "Ajouter un lien",
        "Afegeix un enllaç",
        "Добавить ссылку",
    ],
    [
        "Pausar",
        "Pause",
        "Pausieren",
        "Mettre en pause",
        "Posa en pausa",
        "Приостановить",
    ],
    [
        "Reanudar",
        "Resume",
        "Fortsetzen",
        "Reprendre",
        "Reprèn",
        "Продолжить",
    ],
    [
        "Cancelar",
        "Cancel",
        "Abbrechen",
        "Annuler",
        "Cancel·la",
        "Отменить",
    ],
    [
        "Quitar de la cola",
        "Remove from queue",
        "Aus Warteschlange entfernen",
        "Retirer de la file",
        "Treu de la cua",
        "Убрать из очереди",
    ],
    [
        "Volver a poner en cola",
        "Retry",
        "Erneut einreihen",
        "Remettre en attente",
        "Torna a posar a la cua",
        "Повторить",
    ],
    [
        "Sin límite",
        "No limit",
        "Unbegrenzt",
        "Sans limite",
        "Sense límit",
        "Без лимита",
    ],
    [
        "Máx. {} / s",
        "Max {} / s",
        "Max. {} / s",
        "Max. {} / s",
        "Màx. {} / s",
        "Макс. {} / с",
    ],
    ["parte", "part", "Teil", "partie", "part", "часть"],
    ["partes", "parts", "Teile", "parties", "parts", "частей"],
    [
        "{} recibidos",
        "{} received",
        "{} empfangen",
        "{} reçus",
        "{} rebuts",
        "Получено {}",
    ],
    [
        "Configura cómo Hydra recibe y guarda este archivo.",
        "Choose how Hydra downloads and saves this file.",
        "Lege fest, wie Hydra diese Datei lädt und speichert.",
        "Configurez le téléchargement et l’enregistrement du fichier.",
        "Configura com Hydra rep i desa aquest fitxer.",
        "Настройте загрузку и сохранение файла.",
    ],
    [
        "ENLACE DE DESCARGA",
        "DOWNLOAD LINK",
        "DOWNLOAD-LINK",
        "LIEN DE TÉLÉCHARGEMENT",
        "ENLLAÇ DE BAIXADA",
        "ССЫЛКА ДЛЯ ЗАГРУЗКИ",
    ],
    [
        "Haz clic en el campo y pega con Comando + V.",
        "Click the field and paste with Command + V.",
        "Klicke ins Feld und füge mit Befehlstaste + V ein.",
        "Cliquez dans le champ et collez avec ⌘V.",
        "Fes clic al camp i enganxa amb Comandament + V.",
        "Щёлкните поле и вставьте ссылку клавишами ⌘V.",
    ],
    [
        "NOMBRE DEL ARCHIVO",
        "FILE NAME",
        "DATEINAME",
        "NOM DU FICHIER",
        "NOM DEL FITXER",
        "ИМЯ ФАЙЛА",
    ],
    [
        "CARPETA DE DESTINO",
        "DESTINATION FOLDER",
        "ZIELORDNER",
        "DOSSIER DE DESTINATION",
        "CARPETA DE DESTINACIÓ",
        "ПАПКА НАЗНАЧЕНИЯ",
    ],
    [
        "CONTROLES DE TRANSFERENCIA",
        "TRANSFER CONTROLS",
        "ÜBERTRAGUNGSSTEUERUNG",
        "CONTRÔLES DU TRANSFERT",
        "CONTROLS DE TRANSFERÈNCIA",
        "УПРАВЛЕНИЕ ЗАГРУЗКОЙ",
    ],
    [
        "DIVISIÓN DE PAQUETES",
        "SPLIT INTO PARTS",
        "AUFTEILUNG IN TEILE",
        "DÉCOUPAGE EN PARTIES",
        "DIVISIÓ EN PARTS",
        "РАЗБИТЬ НА ЧАСТИ",
    ],
    [
        "El servidor debe admitir rangos HTTP para aprovechar los segmentos.",
        "The server must support HTTP ranges to use segments.",
        "Der Server muss HTTP-Bereiche unterstützen, damit Segmente genutzt werden.",
        "Le serveur doit accepter les plages HTTP pour utiliser les segments.",
        "El servidor ha d’admetre rangs HTTP per aprofitar els segments.",
        "Для загрузки частями сервер должен поддерживать диапазоны HTTP.",
    ],
    [
        "Iniciar descarga",
        "Start download",
        "Download starten",
        "Lancer le téléchargement",
        "Inicia la baixada",
        "Начать загрузку",
    ],
    [
        "Añadida a la cola",
        "Added to queue",
        "Zur Warteschlange hinzugefügt",
        "Ajouté à la file",
        "Afegida a la cua",
        "Добавлено в очередь",
    ],
    [
        "Usa un enlace que empiece por http:// o https://",
        "Use a link starting with http:// or https://",
        "Verwende einen Link, der mit http:// oder https:// beginnt",
        "Utilisez un lien commençant par http:// ou https://",
        "Fes servir un enllaç que comenci per http:// o https://",
        "Ссылка должна начинаться с http:// или https://",
    ],
    [
        "Escribe un nombre de archivo",
        "Enter a file name",
        "Gib einen Dateinamen ein",
        "Saisissez un nom de fichier",
        "Escriu un nom de fitxer",
        "Введите имя файла",
    ],
    [
        "No se pudo crear la carpeta: {}",
        "Could not create folder: {}",
        "Ordner konnte nicht erstellt werden: {}",
        "Impossible de créer le dossier : {}",
        "No s’ha pogut crear la carpeta: {}",
        "Не удалось создать папку: {}",
    ],
    [
        "No se pudo crear el archivo: {}",
        "Could not create file: {}",
        "Datei konnte nicht erstellt werden: {}",
        "Impossible de créer le fichier : {}",
        "No s’ha pogut crear el fitxer: {}",
        "Не удалось создать файл: {}",
    ],
    [
        "No se pudo preparar el archivo: {}",
        "Could not prepare file: {}",
        "Datei konnte nicht vorbereitet werden: {}",
        "Impossible de préparer le fichier : {}",
        "No s’ha pogut preparar el fitxer: {}",
        "Не удалось подготовить файл: {}",
    ],
    [
        "Error de red: {}",
        "Network error: {}",
        "Netzwerkfehler: {}",
        "Erreur réseau : {}",
        "Error de xarxa: {}",
        "Ошибка сети: {}",
    ],
    [
        "El servidor no aceptó la descarga por segmentos.",
        "The server did not accept a segmented download.",
        "Der Server hat den Download in Segmenten abgelehnt.",
        "Le serveur a refusé le téléchargement segmenté.",
        "El servidor no ha acceptat la baixada per segments.",
        "Сервер отклонил загрузку частями.",
    ],
    [
        "Error recibiendo datos: {}",
        "Error receiving data: {}",
        "Fehler beim Empfangen der Daten: {}",
        "Erreur lors de la réception des données : {}",
        "Error en rebre les dades: {}",
        "Ошибка получения данных: {}",
    ],
    [
        "Error escribiendo el archivo: {}",
        "Error writing file: {}",
        "Fehler beim Schreiben der Datei: {}",
        "Erreur lors de l’écriture du fichier : {}",
        "Error en escriure el fitxer: {}",
        "Ошибка записи файла: {}",
    ],
    [
        "Una parte llegó incompleta. Reintenta la descarga.",
        "A segment was incomplete. Retry the download.",
        "Ein Segment war unvollständig. Starte den Download erneut.",
        "Un segment est incomplet. Relancez le téléchargement.",
        "Una part ha arribat incompleta. Torna-ho a provar.",
        "Часть загружена не полностью. Повторите загрузку.",
    ],
    [
        "La descarga terminó con un tamaño inesperado.",
        "The download finished with an unexpected size.",
        "Der Download endete mit einer unerwarteten Größe.",
        "La taille finale du téléchargement est inattendue.",
        "La baixada ha acabat amb una mida inesperada.",
        "Размер загруженного файла не совпадает с ожидаемым.",
    ],
    [
        "No se pudo iniciar la descarga: {}",
        "Could not start download: {}",
        "Download konnte nicht gestartet werden: {}",
        "Impossible de démarrer le téléchargement : {}",
        "No s’ha pogut iniciar la baixada: {}",
        "Не удалось начать загрузку: {}",
    ],
    [
        "El servidor respondió {}",
        "The server responded {}",
        "Der Server antwortete mit {}",
        "Le serveur a répondu {}",
        "El servidor ha respost {}",
        "Ответ сервера: {}",
    ],
    [
        "Descarga cancelada",
        "Download cancelled",
        "Download abgebrochen",
        "Téléchargement annulé",
        "Baixada cancel·lada",
        "Загрузка отменена",
    ],
    [
        "Copiar enlace",
        "Copy link",
        "Link kopieren",
        "Copier le lien",
        "Copia l’enllaç",
        "Копировать ссылку",
    ],
    [
        "Mostrar en Finder",
        "Show in Finder",
        "Im Finder anzeigen",
        "Afficher dans le Finder",
        "Mostra al Finder",
        "Показать в Finder",
    ],
    [
        "No se pudo abrir Finder",
        "Could not open Finder",
        "Finder konnte nicht geöffnet werden",
        "Impossible d’ouvrir le Finder",
        "No s’ha pogut obrir el Finder",
        "Не удалось открыть Finder",
    ],
];

const _: () = assert!(TRANSLATIONS.len() == Text::Count as usize);

fn tr(language: Language, key: Text) -> &'static str {
    TRANSLATIONS[key as usize][language as usize]
}

fn tr_arg(language: Language, key: Text, value: impl std::fmt::Display) -> String {
    tr(language, key).replace("{}", &value.to_string())
}

fn language_from_context(ctx: &egui::Context) -> Language {
    ctx.data(|data| data.get_temp::<Language>(egui::Id::unique("hydra_language")))
        .unwrap_or_default()
}

#[derive(Serialize, Deserialize)]
#[serde(default)]
struct AppSettings {
    language: Language,
    theme: UiTheme,
    accent: AccentTheme,
    ui_scale: f32,
    compact_mode: bool,
    animations: bool,
    animation_duration: f32,
    default_directory: PathBuf,
    default_segments: usize,
    default_priority: Priority,
    unlimited_speed: bool,
    speed_limit_mb: f32,
    max_concurrent: usize,
}

impl Default for AppSettings {
    fn default() -> Self {
        let home = std::env::var_os("HOME")
            .map(PathBuf::from)
            .unwrap_or_else(|| PathBuf::from("."));
        Self {
            language: Language::Spanish,
            theme: UiTheme::Dark,
            accent: AccentTheme::Mint,
            ui_scale: 1.0,
            compact_mode: false,
            animations: true,
            animation_duration: 0.24,
            default_directory: home.join("Downloads"),
            default_segments: 4,
            default_priority: Priority::Normal,
            unlimited_speed: true,
            speed_limit_mb: 8.0,
            max_concurrent: 3,
        }
    }
}

struct DownloadManager {
    tasks: Vec<Arc<DownloadTask>>,
    next_id: u64,
}

#[derive(Serialize, Deserialize)]
struct PersistedDownload {
    id: u64,
    #[serde(default)]
    language: Language,
    url: String,
    path: PathBuf,
    file_name: String,
    segments: usize,
    effective_segments: u8,
    speed_limit: u64,
    priority: Priority,
    status: DownloadStatus,
    progress: u64,
    total: u64,
    error: Option<String>,
}

impl DownloadManager {
    fn new() -> Self {
        Self {
            tasks: Vec::new(),
            next_id: 1,
        }
    }

    fn restore(saved: Vec<PersistedDownload>) -> Self {
        let mut manager = Self::new();
        for saved in saved {
            let interrupted = matches!(
                saved.status,
                DownloadStatus::Downloading | DownloadStatus::Paused
            );
            let status = if interrupted {
                DownloadStatus::Queued
            } else {
                saved.status
            };
            let id = saved.id;
            manager.next_id = manager.next_id.max(id.saturating_add(1));
            manager.tasks.push(Arc::new(DownloadTask {
                id,
                language: saved.language,
                url: saved.url,
                path: saved.path,
                file_name: saved.file_name,
                segments: saved.segments.clamp(1, 16),
                effective_segments: AtomicU8::new(if interrupted {
                    saved.segments.clamp(1, 16) as u8
                } else {
                    saved.effective_segments.max(1)
                }),
                speed_limit: AtomicU64::new(saved.speed_limit),
                priority: AtomicU8::new(saved.priority.value()),
                status: Mutex::new(status),
                progress: AtomicU64::new(if interrupted { 0 } else { saved.progress }),
                total: AtomicU64::new(if interrupted { 0 } else { saved.total }),
                speed: AtomicU64::new(0),
                control: AtomicU8::new(0),
                error: Mutex::new(if interrupted { None } else { saved.error }),
                meter: Mutex::new(SpeedMeter {
                    started: Instant::now(),
                    bytes: 0,
                }),
                limiter: RateLimiter::new(),
            }));
        }
        manager
    }

    fn snapshot(&self) -> Vec<PersistedDownload> {
        self.tasks
            .iter()
            .map(|task| PersistedDownload {
                id: task.id,
                language: task.language,
                url: task.url.clone(),
                path: task.path.clone(),
                file_name: task.file_name.clone(),
                segments: task.segments,
                effective_segments: task.effective_segments.load(Ordering::Relaxed),
                speed_limit: task.speed_limit.load(Ordering::Relaxed),
                priority: Priority::from_u8(task.priority.load(Ordering::Relaxed)),
                status: task.status(),
                progress: task.progress.load(Ordering::Relaxed),
                total: task.total.load(Ordering::Relaxed),
                error: task.error.lock().unwrap_or_else(|e| e.into_inner()).clone(),
            })
            .collect()
    }

    fn add(&mut self, draft: &NewDownload, language: Language) -> Result<(), AddError> {
        let url = draft.url.trim();
        if !(url.starts_with("https://") || url.starts_with("http://")) {
            return Err(AddError::InvalidUrl);
        }
        let name_input = if draft.file_name.trim().is_empty() {
            suggested_filename(url)
        } else {
            draft.file_name.clone()
        };
        let file_name = safe_file_name(&name_input);
        if file_name.is_empty() {
            return Err(AddError::MissingFilename);
        }
        let directory = draft.directory.clone();
        let path = unique_path(&directory, &file_name, &self.tasks);
        let stored_name = path
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or(&file_name)
            .to_owned();
        let speed_limit = if draft.unlimited_speed {
            0
        } else {
            (draft.speed_limit_mb.max(0.1) * 1024.0 * 1024.0) as u64
        };
        let task = Arc::new(DownloadTask {
            id: self.next_id,
            language,
            url: url.to_owned(),
            path,
            file_name: stored_name,
            segments: draft.segments.clamp(1, 16),
            effective_segments: AtomicU8::new(draft.segments.clamp(1, 16) as u8),
            speed_limit: AtomicU64::new(speed_limit),
            priority: AtomicU8::new(draft.priority.value()),
            status: Mutex::new(DownloadStatus::Queued),
            progress: AtomicU64::new(0),
            total: AtomicU64::new(0),
            speed: AtomicU64::new(0),
            control: AtomicU8::new(0),
            error: Mutex::new(None),
            meter: Mutex::new(SpeedMeter {
                started: Instant::now(),
                bytes: 0,
            }),
            limiter: RateLimiter::new(),
        });
        self.next_id += 1;
        self.tasks.push(task);
        Ok(())
    }

    fn launch_queued(&self, runtime: &Runtime, max_active: usize) {
        let active = self
            .tasks
            .iter()
            .filter(|task| {
                matches!(
                    task.status(),
                    DownloadStatus::Downloading | DownloadStatus::Paused
                )
            })
            .count();
        if active >= max_active {
            return;
        }
        let mut queue: Vec<_> = self
            .tasks
            .iter()
            .filter(|task| task.status() == DownloadStatus::Queued)
            .cloned()
            .collect();
        queue.sort_by_key(|task| std::cmp::Reverse(task.priority.load(Ordering::Relaxed)));
        for task in queue.into_iter().take(max_active - active) {
            task.control.store(0, Ordering::Relaxed);
            task.set_status(DownloadStatus::Downloading);
            runtime.spawn(download(task));
        }
    }

    fn count(&self, filter: impl Fn(DownloadStatus) -> bool) -> usize {
        self.tasks
            .iter()
            .filter(|task| filter(task.status()))
            .count()
    }

    fn current_speed(&self) -> u64 {
        self.tasks
            .iter()
            .filter(|task| task.status() == DownloadStatus::Downloading)
            .map(|task| task.speed.load(Ordering::Relaxed))
            .sum()
    }
}

#[derive(Debug)]
enum AddError {
    InvalidUrl,
    MissingFilename,
}

struct NewDownload {
    url: String,
    file_name: String,
    directory: PathBuf,
    segments: usize,
    unlimited_speed: bool,
    speed_limit_mb: f32,
    priority: Priority,
}

impl NewDownload {
    fn from_settings(settings: &AppSettings) -> Self {
        Self {
            url: String::new(),
            file_name: String::new(),
            directory: settings.default_directory.clone(),
            segments: settings.default_segments.clamp(1, 16),
            unlimited_speed: settings.unlimited_speed,
            speed_limit_mb: settings.speed_limit_mb,
            priority: settings.default_priority,
        }
    }
}

struct HydraApp {
    manager: DownloadManager,
    runtime: Runtime,
    settings: AppSettings,
    view: View,
    transition_started: Instant,
    search: String,
    show_new: bool,
    draft: NewDownload,
    toast: Option<(Instant, String, bool)>,
}

impl HydraApp {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let settings = cc
            .storage
            .and_then(|storage| eframe::get_value(storage, "hydra_preferences"))
            .unwrap_or_default();
        apply_appearance(&cc.egui_ctx, &settings);
        let draft = NewDownload::from_settings(&settings);
        let saved_downloads = cc
            .storage
            .and_then(|storage| eframe::get_value(storage, "hydra_downloads"))
            .unwrap_or_default();
        Self {
            manager: DownloadManager::restore(saved_downloads),
            runtime: Runtime::new().expect("No se pudo iniciar el motor async"),
            settings,
            view: View::All,
            transition_started: Instant::now(),
            search: String::new(),
            show_new: false,
            draft,
            toast: None,
        }
    }

    fn set_toast(&mut self, text: impl Into<String>, error: bool) {
        self.toast = Some((Instant::now(), text.into(), error));
    }

    fn set_view(&mut self, view: View) {
        if self.view != view {
            self.view = view;
            self.transition_started = Instant::now();
        }
    }

    fn visible_tasks(&self) -> Vec<Arc<DownloadTask>> {
        let needle = self.search.to_lowercase();
        self.manager
            .tasks
            .iter()
            .filter(|task| {
                let status = task.status();
                let view_matches = match self.view {
                    View::All => true,
                    View::Active => {
                        matches!(status, DownloadStatus::Downloading | DownloadStatus::Paused)
                    }
                    View::Queue => status == DownloadStatus::Queued,
                    View::Finished => matches!(
                        status,
                        DownloadStatus::Completed
                            | DownloadStatus::Failed
                            | DownloadStatus::Cancelled
                    ),
                    View::Settings => false,
                };
                view_matches
                    && (needle.is_empty() || task.file_name.to_lowercase().contains(&needle))
            })
            .cloned()
            .collect()
    }

    fn draw_sidebar(&mut self, root: &mut egui::Ui) {
        let p = palette(root);
        let language = language_from_context(root.ctx());
        egui::Panel::left("hydra_sidebar")
            .default_size(232.0)
            .resizable(false)
            .frame(egui::Frame::new().fill(p.sidebar).inner_margin(18))
            .show(root, |ui| {
                ui.horizontal(|ui| {
                    draw_hydra_mark(
                        ui,
                        40.0,
                        self.settings.accent.color_for(self.settings.theme),
                    );
                    ui.vertical(|ui| {
                        ui.label(
                            egui::RichText::new("HYDRA")
                                .size(16.0)
                                .strong()
                                .color(p.text),
                        );
                        ui.label(
                            egui::RichText::new("MANAGER")
                                .size(10.0)
                                .strong()
                                .color(p.muted),
                        );
                    });
                });
                ui.add_space(34.0);
                ui.label(
                    egui::RichText::new(tr(language, Text::Library))
                        .size(10.0)
                        .strong()
                        .color(p.muted),
                );
                ui.add_space(9.0);
                self.sidebar_item(
                    ui,
                    View::All,
                    IconKind::Files,
                    Text::All,
                    self.manager.tasks.len(),
                );
                self.sidebar_item(
                    ui,
                    View::Active,
                    IconKind::Activity,
                    Text::Active,
                    self.manager.count(|s| {
                        matches!(s, DownloadStatus::Downloading | DownloadStatus::Paused)
                    }),
                );
                self.sidebar_item(
                    ui,
                    View::Queue,
                    IconKind::Queue,
                    Text::Queue,
                    self.manager.count(|s| s == DownloadStatus::Queued),
                );
                self.sidebar_item(
                    ui,
                    View::Finished,
                    IconKind::Check,
                    Text::Finished,
                    self.manager.count(|s| {
                        matches!(
                            s,
                            DownloadStatus::Completed
                                | DownloadStatus::Failed
                                | DownloadStatus::Cancelled
                        )
                    }),
                );
                self.sidebar_item(ui, View::Settings, IconKind::Settings, Text::Personalize, 0);

                ui.with_layout(egui::Layout::bottom_up(egui::Align::Min), |ui| {
                    egui::Frame::new()
                        .fill(p.panel)
                        .stroke(egui::Stroke::new(1.0, p.line))
                        .inner_margin(14)
                        .show(ui, |ui| {
                            ui.horizontal(|ui| {
                                let (dot, _) = ui.allocate_exact_size(
                                    egui::vec2(13.0, 13.0),
                                    egui::Sense::hover(),
                                );
                                ui.painter().circle_filled(
                                    dot.center(),
                                    4.0,
                                    self.settings.accent.color_for(self.settings.theme),
                                );
                                ui.label(
                                    egui::RichText::new("HYDRA")
                                        .size(10.0)
                                        .strong()
                                        .color(p.text),
                                );
                            });
                            ui.add_space(6.0);
                            ui.label(
                                egui::RichText::new(tr(
                                    language_from_context(ui.ctx()),
                                    Text::EngineReady,
                                ))
                                .size(11.0)
                                .color(p.muted),
                            );
                        });
                    ui.add_space(10.0);
                    ui.label(
                        egui::RichText::new("HYDRA MANAGER  ·  0.1.0")
                            .size(9.0)
                            .color(p.muted),
                    );
                });
            });
    }

    fn sidebar_item(
        &mut self,
        ui: &mut egui::Ui,
        view: View,
        icon: IconKind,
        label: Text,
        count: usize,
    ) {
        let p = palette(ui);
        let language = language_from_context(ui.ctx());
        let selected = self.view == view;
        let progress = if self.settings.animations {
            ui.ctx().animate_bool_with_time(
                egui::Id::unique(("hydra_sidebar_selection", view)),
                selected,
                self.settings.animation_duration,
            )
        } else {
            if selected { 1.0 } else { 0.0 }
        };
        let bg = with_alpha(p.selected, progress);
        egui::Frame::new()
            .fill(bg)
            .inner_margin(egui::Margin::symmetric(10, 9))
            .show(ui, |ui| {
                ui.set_width(ui.available_width());
                ui.horizontal(|ui| {
                    let icon_color = if selected {
                        self.settings.accent.color_for(self.settings.theme)
                    } else {
                        p.muted
                    };
                    let response = draw_icon(ui, icon, 18.0, icon_color);
                    let response = response.union(
                        ui.add(
                            egui::Button::new(
                                egui::RichText::new(tr(language, label))
                                    .size(13.0)
                                    .color(if selected { p.text } else { p.muted }),
                            )
                            .frame(false)
                            .min_size(egui::vec2(82.0, 20.0)),
                        ),
                    );
                    if view != View::Settings {
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            ui.label(egui::RichText::new(count.to_string()).size(11.0).color(
                                if selected {
                                    self.settings.accent.color_for(self.settings.theme)
                                } else {
                                    p.muted
                                },
                            ));
                        });
                    }
                    if response.clicked() {
                        self.set_view(view);
                    }
                });
            });
        ui.add_space(3.0);
    }

    fn draw_main(&mut self, root: &mut egui::Ui) {
        let p = palette(root);
        let ctx = root.ctx().clone();
        let language = self.settings.language;
        let duration = self.settings.animation_duration.clamp(0.1, 0.8);
        let page_progress = if self.settings.animations {
            (self.transition_started.elapsed().as_secs_f32() / duration).clamp(0.0, 1.0)
        } else {
            1.0
        };
        if page_progress < 1.0 {
            ctx.request_repaint_after(Duration::from_millis(16));
        }
        egui::CentralPanel::default()
            .frame(egui::Frame::new().fill(p.bg).inner_margin(24))
            .show(root, |ui| {
                let eased = 1.0 - (1.0 - page_progress).powi(3);
                ui.set_opacity(0.55 + 0.45 * eased);
                ui.horizontal(|ui| {
                    ui.vertical(|ui| {
                        ui.label(
                            egui::RichText::new(tr(
                                language,
                                match self.view {
                                    View::All => Text::Downloads,
                                    View::Active => Text::Active,
                                    View::Queue => Text::DownloadQueue,
                                    View::Finished => Text::Finished,
                                    View::Settings => Text::Personalization,
                                },
                            ))
                            .size(25.0)
                            .strong()
                            .color(p.text),
                        );
                        ui.label(
                            egui::RichText::new(tr(
                                language,
                                if self.view == View::Settings {
                                    Text::SettingsSubtitle
                                } else {
                                    Text::ManageSubtitle
                                },
                            ))
                            .size(12.0)
                            .color(p.muted),
                        );
                    });
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if self.view == View::Settings {
                            if ui.button(tr(language, Text::BackToDownloads)).clicked() {
                                self.set_view(View::All);
                            }
                        } else {
                            if ui
                                .add(
                                    egui::Button::new(
                                        egui::RichText::new(tr(language, Text::NewDownload))
                                            .size(13.0)
                                            .strong()
                                            .color(p.bg),
                                    )
                                    .fill(self.settings.accent.color_for(self.settings.theme))
                                    .min_size(egui::vec2(154.0, 38.0)),
                                )
                                .clicked()
                            {
                                self.show_new = true;
                            }
                            ui.add_space(10.0);
                            ui.horizontal(|ui| {
                                draw_icon(ui, IconKind::Search, 15.0, p.muted);
                                ui.add(
                                    egui::TextEdit::singleline(&mut self.search)
                                        .hint_text(tr(language, Text::SearchFile))
                                        .desired_width(158.0),
                                );
                            });
                        }
                    });
                });

                if self.view == View::Settings {
                    ui.add_space(22.0);
                    self.draw_settings(ui);
                } else {
                    ui.add_space(22.0);
                    self.draw_overview(ui);
                    ui.add_space(23.0);
                    ui.horizontal(|ui| {
                        ui.label(
                            egui::RichText::new(tr(language, Text::Transfers))
                                .size(10.0)
                                .strong()
                                .color(p.muted),
                        );
                        ui.add_space(8.0);
                        ui.label(
                            egui::RichText::new(format!("{:02}", self.visible_tasks().len()))
                                .size(10.0)
                                .color(p.muted),
                        );
                        ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                            ui.label(
                                egui::RichText::new(tr_arg(
                                    language,
                                    Text::UpToConcurrent,
                                    self.settings.max_concurrent,
                                ))
                                .size(10.0)
                                .color(p.muted),
                            );
                        });
                    });
                    ui.add_space(10.0);

                    let tasks = self.visible_tasks();
                    if tasks.is_empty() {
                        self.draw_empty(ui);
                    } else {
                        egui::ScrollArea::vertical()
                            .auto_shrink([false, false])
                            .show(ui, |ui| {
                                for task in tasks {
                                    self.draw_task(ui, &task);
                                    ui.add_space(9.0);
                                }
                            });
                    }
                }
            });
    }

    fn draw_settings(&mut self, ui: &mut egui::Ui) {
        let p = palette(ui);
        let language = self.settings.language;
        let original_language = self.settings.language;
        let original_theme = self.settings.theme;
        let original_accent = self.settings.accent;
        let original_scale = self.settings.ui_scale;
        let original_compact = self.settings.compact_mode;
        let original_animations = self.settings.animations;
        let original_animation_duration = self.settings.animation_duration;

        ui.columns(2, |columns| {
            settings_card(&mut columns[0], Text::Appearance, |ui| {
                ui.horizontal(|ui| {
                    ui.label(
                        egui::RichText::new(tr(language, Text::Language))
                            .strong()
                            .color(p.text),
                    );
                    egui::ComboBox::from_id_salt("settings_language")
                        .selected_text(self.settings.language.native_name())
                        .show_ui(ui, |ui| {
                            for choice in Language::ALL {
                                ui.selectable_value(
                                    &mut self.settings.language,
                                    choice,
                                    choice.native_name(),
                                );
                            }
                        });
                });
                ui.add_space(8.0);
                ui.label(
                    egui::RichText::new(tr(language, Text::ThemeInterface))
                        .strong()
                        .color(p.text),
                );
                ui.add_space(7.0);
                ui.horizontal(|ui| {
                    for theme in [UiTheme::Dark, UiTheme::Light, UiTheme::Monochrome] {
                        let selected = self.settings.theme == theme;
                        let fill = if selected { p.selected } else { p.panel_hi };
                        if ui
                            .add(
                                egui::Button::new(
                                    egui::RichText::new(theme.label(language))
                                        .size(11.0)
                                        .color(p.text),
                                )
                                .fill(fill)
                                .stroke(egui::Stroke::new(1.0, p.line))
                                .min_size(egui::vec2(96.0, 32.0)),
                            )
                            .clicked()
                        {
                            self.settings.theme = theme;
                        }
                    }
                });
                ui.add_space(13.0);
                ui.label(
                    egui::RichText::new(tr(language, Text::AccentColor))
                        .strong()
                        .color(p.text),
                );
                ui.add_space(9.0);
                ui.horizontal_wrapped(|ui| {
                    for accent in [
                        AccentTheme::Mint,
                        AccentTheme::Sky,
                        AccentTheme::Violet,
                        AccentTheme::Amber,
                    ] {
                        let selected = self.settings.accent == accent;
                        let (rect, response) =
                            ui.allocate_exact_size(egui::vec2(38.0, 38.0), egui::Sense::click());
                        let ring = if selected { p.text } else { p.line };
                        ui.painter().circle_stroke(
                            rect.center(),
                            15.0,
                            egui::Stroke::new(2.0, ring),
                        );
                        ui.painter()
                            .circle_filled(rect.center(), 10.0, accent.color());
                        let response = response.on_hover_text(accent.label(language));
                        if response.clicked() {
                            self.settings.accent = accent;
                        }
                    }
                });
                ui.label(
                    egui::RichText::new(
                        tr(language, Text::SelectedAccent)
                            .replace("{}", self.settings.accent.label(language)),
                    )
                    .size(10.0)
                    .color(p.muted),
                );
                ui.add_space(14.0);
                ui.label(
                    egui::RichText::new(tr(language, Text::UiScale))
                        .strong()
                        .color(p.text),
                );
                ui.add(
                    egui::Slider::new(&mut self.settings.ui_scale, 0.85..=1.25)
                        .custom_formatter(|value, _| format!("{}%", (value * 100.0).round())),
                );
                ui.label(
                    egui::RichText::new(tr(language, Text::Autosave))
                        .size(10.0)
                        .color(p.muted),
                );
                ui.add_space(10.0);
                ui.checkbox(
                    &mut self.settings.compact_mode,
                    tr(language, Text::CompactMode),
                );
                ui.add_space(4.0);
                ui.checkbox(
                    &mut self.settings.animations,
                    tr(language, Text::FluidAnimations),
                );
                if self.settings.animations {
                    ui.label(
                        egui::RichText::new(tr(language, Text::TransitionDuration))
                            .size(10.0)
                            .color(p.muted),
                    );
                    ui.add(
                        egui::Slider::new(&mut self.settings.animation_duration, 0.12..=0.60)
                            .custom_formatter(|value, _| {
                                format!("{} ms", (value * 1000.0).round())
                            }),
                    );
                }
            });

            settings_card(&mut columns[1], Text::DefaultDownloads, |ui| {
                ui.label(
                    egui::RichText::new(tr(language, Text::Destination))
                        .strong()
                        .color(p.text),
                );
                ui.horizontal(|ui| {
                    ui.label(
                        egui::RichText::new(self.settings.default_directory.display().to_string())
                            .size(10.0)
                            .color(p.muted),
                    );
                    if ui.button(tr(language, Text::ChooseFolder)).clicked() {
                        if let Some(folder) = rfd::FileDialog::new()
                            .set_directory(&self.settings.default_directory)
                            .pick_folder()
                        {
                            self.settings.default_directory = folder;
                        }
                    }
                });
                ui.add_space(9.0);
                ui.label(
                    egui::RichText::new(tr(language, Text::SegmentsPerFile))
                        .strong()
                        .color(p.text),
                );
                ui.add(
                    egui::Slider::new(&mut self.settings.default_segments, 1..=16)
                        .suffix(tr(language, Text::PartsSuffix)),
                );
                ui.horizontal(|ui| {
                    ui.label(
                        egui::RichText::new(tr(language, Text::Priority))
                            .strong()
                            .color(p.text),
                    );
                    egui::ComboBox::from_id_salt("settings_priority")
                        .selected_text(self.settings.default_priority.label(language))
                        .show_ui(ui, |ui| {
                            for priority in [Priority::Low, Priority::Normal, Priority::High] {
                                ui.selectable_value(
                                    &mut self.settings.default_priority,
                                    priority,
                                    priority.label(language),
                                );
                            }
                        });
                });
                ui.checkbox(
                    &mut self.settings.unlimited_speed,
                    tr(language, Text::UnlimitedSpeed),
                );
                if !self.settings.unlimited_speed {
                    ui.horizontal(|ui| {
                        ui.label(tr(language, Text::MaxPerFile));
                        ui.add(
                            egui::DragValue::new(&mut self.settings.speed_limit_mb)
                                .range(0.1..=500.0)
                                .speed(0.2)
                                .suffix(" MB/s"),
                        );
                    });
                }
                ui.add_space(8.0);
                ui.label(
                    egui::RichText::new(tr(language, Text::SimultaneousDownloads))
                        .strong()
                        .color(p.text),
                );
                ui.add(
                    egui::Slider::new(&mut self.settings.max_concurrent, 1..=6)
                        .suffix(tr(language, Text::ActiveSuffix)),
                );
            });
        });

        if original_language != self.settings.language
            || original_theme != self.settings.theme
            || original_accent != self.settings.accent
            || (original_scale - self.settings.ui_scale).abs() > f32::EPSILON
            || original_compact != self.settings.compact_mode
            || original_animations != self.settings.animations
            || (original_animation_duration - self.settings.animation_duration).abs() > f32::EPSILON
        {
            apply_appearance(ui.ctx(), &self.settings);
        }
    }

    fn draw_overview(&self, ui: &mut egui::Ui) {
        let p = palette(ui);
        let language = language_from_context(ui.ctx());
        let completed = self.manager.count(|s| s == DownloadStatus::Completed);
        let active = self.manager.count(|s| s == DownloadStatus::Downloading);
        let speed = self.manager.current_speed();
        ui.columns(3, |columns| {
            overview_card(
                &mut columns[0],
                Text::Files,
                self.manager.tasks.len().to_string(),
                tr(language, Text::InYourList).to_owned(),
                p.blue,
                IconKind::Files,
            );
            overview_card(
                &mut columns[1],
                Text::InProgress,
                active.to_string(),
                tr(language, Text::ActiveTransfers).to_owned(),
                self.settings.accent.color_for(self.settings.theme),
                IconKind::Transfer,
            );
            overview_card(
                &mut columns[2],
                Text::CompletedLabel,
                completed.to_string(),
                format!(
                    "{}{}",
                    format_bytes(
                        self.manager
                            .tasks
                            .iter()
                            .filter(|t| t.status() == DownloadStatus::Completed)
                            .map(|t| t.total.load(Ordering::Relaxed))
                            .sum()
                    ),
                    tr(language, Text::TotalSuffix)
                ),
                p.amber,
                IconKind::Check,
            );
        });
        ui.add_space(9.0);
        ui.horizontal(|ui| {
            ui.label(
                egui::RichText::new(tr(language, Text::TotalSpeed))
                    .size(9.0)
                    .strong()
                    .color(p.muted),
            );
            ui.label(
                egui::RichText::new(format!("{} / s", format_bytes(speed)))
                    .size(11.0)
                    .strong()
                    .color(self.settings.accent.color_for(self.settings.theme)),
            );
        });
    }

    fn draw_empty(&mut self, ui: &mut egui::Ui) {
        let p = palette(ui);
        let language = language_from_context(ui.ctx());
        egui::Frame::new()
            .fill(p.panel)
            .stroke(egui::Stroke::new(1.0, p.line))
            .inner_margin(30)
            .show(ui, |ui| {
                ui.set_min_height(220.0);
                ui.vertical_centered(|ui| {
                    draw_hydra_mark(
                        ui,
                        52.0,
                        self.settings.accent.color_for(self.settings.theme),
                    );
                    ui.add_space(12.0);
                    ui.label(
                        egui::RichText::new(tr(language, Text::AllClear))
                            .size(18.0)
                            .strong()
                            .color(p.text),
                    );
                    ui.label(
                        egui::RichText::new(tr(language, Text::AddLinkDescription))
                            .size(12.0)
                            .color(p.muted),
                    );
                    ui.add_space(10.0);
                    if ui
                        .add(
                            egui::Button::new(tr(language, Text::AddLink))
                                .fill(p.selected)
                                .stroke(egui::Stroke::new(1.0, p.line)),
                        )
                        .clicked()
                    {
                        self.show_new = true;
                    }
                });
            });
    }

    fn draw_task(&mut self, ui: &mut egui::Ui, task: &Arc<DownloadTask>) {
        let p = palette(ui);
        let language = language_from_context(ui.ctx());
        let status = task.status();
        let done = task.progress.load(Ordering::Relaxed);
        let total = task.total.load(Ordering::Relaxed);
        let fraction = if total > 0 {
            (done as f32 / total as f32).clamp(0.0, 1.0)
        } else {
            0.0
        };
        let error = task.error.lock().unwrap_or_else(|e| e.into_inner()).clone();
        let animated_fraction = if self.settings.animations {
            ui.ctx().animate_value_with_time(
                egui::Id::unique(("hydra_progress", task.id)),
                fraction,
                self.settings.animation_duration,
            )
        } else {
            fraction
        };
        egui::Frame::new()
            .fill(p.panel)
            .stroke(egui::Stroke::new(1.0, p.line))
            .inner_margin(15)
            .show(ui, |ui| {
                ui.horizontal(|ui| {
                    egui::Frame::new()
                        .fill(p.card_icon)
                        .inner_margin(11)
                        .show(ui, |ui| {
                            draw_icon(
                                ui,
                                IconKind::Download,
                                20.0,
                                self.settings.accent.color_for(self.settings.theme),
                            );
                        });
                    ui.vertical(|ui| {
                        ui.horizontal(|ui| {
                            ui.label(
                                egui::RichText::new(&task.file_name)
                                    .size(13.0)
                                    .strong()
                                    .color(p.text),
                            );
                            ui.label(
                                egui::RichText::new(format!("#{}", task.id))
                                    .size(9.0)
                                    .color(p.muted),
                            );
                        });
                        ui.label(
                            egui::RichText::new(path_parent(&task.path, language))
                                .size(10.0)
                                .color(p.muted),
                        );
                    });
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if status == DownloadStatus::Downloading || status == DownloadStatus::Paused
                        {
                            if status == DownloadStatus::Downloading {
                                if icon_button(ui, IconKind::Pause, p.muted, Text::Pause) {
                                    task.control.store(1, Ordering::Relaxed);
                                    task.set_status(DownloadStatus::Paused);
                                }
                            } else if icon_button(ui, IconKind::Play, p.muted, Text::Resume) {
                                task.control.store(0, Ordering::Relaxed);
                                task.set_status(DownloadStatus::Downloading);
                            }
                            if icon_button(ui, IconKind::Close, p.muted, Text::Cancel) {
                                task.control.store(2, Ordering::Relaxed);
                                task.set_status(DownloadStatus::Cancelled);
                            }
                        } else if status == DownloadStatus::Queued {
                            if icon_button(ui, IconKind::Close, p.muted, Text::RemoveFromQueue) {
                                task.set_status(DownloadStatus::Cancelled);
                            }
                        } else if status == DownloadStatus::Failed
                            || status == DownloadStatus::Cancelled
                        {
                            if icon_button(ui, IconKind::Retry, p.muted, Text::RetryQueue) {
                                task.progress.store(0, Ordering::Relaxed);
                                task.total.store(0, Ordering::Relaxed);
                                task.error.lock().unwrap_or_else(|e| e.into_inner()).take();
                                task.control.store(0, Ordering::Relaxed);
                                task.set_status(DownloadStatus::Queued);
                            }
                        }
                        if icon_button(ui, IconKind::Reveal, p.muted, Text::RevealInFinder)
                            && std::process::Command::new("open")
                                .arg("-R")
                                .arg(&task.path)
                                .spawn()
                                .is_err()
                        {
                            self.set_toast(tr(language, Text::OpenFolderFailed), true);
                        }
                        if icon_button(ui, IconKind::Copy, p.muted, Text::CopyLink) {
                            ui.ctx().copy_text(task.url.clone());
                            self.set_toast(tr(language, Text::CopyLink), false);
                        }
                        status_pill(
                            ui,
                            status,
                            self.settings.accent.color_for(self.settings.theme),
                        );
                    });
                });
                ui.add_space(13.0);
                ui.horizontal(|ui| {
                    ui.add(
                        egui::ProgressBar::new(animated_fraction)
                            .show_percentage()
                            .desired_width(ui.available_width() - 200.0)
                            .fill(
                                status
                                    .color(self.settings.accent.color_for(self.settings.theme), p),
                            ),
                    );
                    ui.label(
                        egui::RichText::new(if total > 0 {
                            format!("{} / {}", format_bytes(done), format_bytes(total))
                        } else {
                            tr(language, Text::Received).replace("{}", &format_bytes(done))
                        })
                        .size(10.0)
                        .color(p.muted),
                    );
                });
                ui.add_space(8.0);
                ui.horizontal(|ui| {
                    let speed = task.speed.load(Ordering::Relaxed);
                    ui.label(
                        egui::RichText::new(if status == DownloadStatus::Downloading {
                            format!("{} / s", format_bytes(speed))
                        } else {
                            "— / s".into()
                        })
                        .size(10.0)
                        .strong()
                        .color(if status == DownloadStatus::Downloading {
                            self.settings.accent.color_for(self.settings.theme)
                        } else {
                            p.muted
                        }),
                    );
                    let parts = task.effective_segments.load(Ordering::Relaxed) as usize;
                    ui.label(
                        egui::RichText::new(format!(
                            "{} {}",
                            parts,
                            if parts == 1 {
                                tr(language, Text::PartOne)
                            } else {
                                tr(language, Text::PartMany)
                            }
                        ))
                        .size(10.0)
                        .color(p.muted),
                    );
                    let limit = task.speed_limit.load(Ordering::Relaxed);
                    ui.label(
                        egui::RichText::new(if limit == 0 {
                            tr(language, Text::NoLimit).into()
                        } else {
                            tr(language, Text::MaxSpeed).replace("{}", &format_bytes(limit))
                        })
                        .size(10.0)
                        .color(p.muted),
                    );
                    ui.add_space(4.0);
                    ui.label(
                        egui::RichText::new(tr(language, Text::Priority))
                            .size(10.0)
                            .color(p.muted),
                    );
                    let mut priority = Priority::from_u8(task.priority.load(Ordering::Relaxed));
                    egui::ComboBox::from_id_salt(("priority", task.id))
                        .selected_text(priority.label(language))
                        .width(82.0)
                        .show_ui(ui, |ui| {
                            for choice in [Priority::Low, Priority::Normal, Priority::High] {
                                ui.selectable_value(&mut priority, choice, choice.label(language));
                            }
                        });
                    if priority.value() != task.priority.load(Ordering::Relaxed) {
                        task.priority.store(priority.value(), Ordering::Relaxed);
                    }
                });
                if let Some(error) = error {
                    ui.add_space(5.0);
                    ui.label(egui::RichText::new(error).size(10.0).color(p.red));
                }
            });
    }

    fn draw_new_dialog(&mut self, ctx: &egui::Context) {
        if !self.show_new {
            return;
        }
        let p = palette_from_context(ctx);
        let mut keep_open = true;
        let mut request_close = false;
        let language = self.settings.language;
        egui::Window::new(tr(language, Text::NewDownload))
            .collapsible(false)
            .resizable(false)
            .fixed_size(egui::vec2(590.0, 545.0))
            .anchor(egui::Align2::CENTER_CENTER, egui::vec2(0.0, 0.0))
            .open(&mut keep_open)
            .show(ctx, |ui| {
                ui.label(
                    egui::RichText::new(tr(language, Text::NewDownloadDescription))
                        .size(12.0)
                        .color(p.muted),
                );
                ui.add_space(13.0);
                field_label(ui, Text::LinkLabel);
                ui.label(
                    egui::RichText::new(tr(language, Text::PasteHint))
                        .size(10.0)
                        .color(p.muted),
                );
                let response = ui.add(
                    egui::TextEdit::singleline(&mut self.draft.url)
                        .hint_text("https://servidor.com/archivo.zip")
                        .desired_width(f32::INFINITY),
                );
                if response.lost_focus() && self.draft.file_name.is_empty() {
                    self.draft.file_name = suggested_filename(&self.draft.url);
                }
                ui.add_space(11.0);
                field_label(ui, Text::FileName);
                ui.add(
                    egui::TextEdit::singleline(&mut self.draft.file_name)
                        .hint_text("archivo.zip")
                        .desired_width(f32::INFINITY),
                );
                ui.add_space(11.0);
                field_label(ui, Text::DestinationFolder);
                ui.horizontal(|ui| {
                    let mut directory_label = self.draft.directory.display().to_string();
                    ui.add(
                        egui::TextEdit::singleline(&mut directory_label)
                            .desired_width(405.0)
                            .interactive(false),
                    );
                    if ui.button(tr(language, Text::ChooseFolder)).clicked() {
                        if let Some(folder) = rfd::FileDialog::new()
                            .set_directory(&self.draft.directory)
                            .pick_folder()
                        {
                            self.draft.directory = folder;
                        }
                    }
                });
                ui.add_space(16.0);
                ui.separator();
                ui.add_space(8.0);
                ui.label(
                    egui::RichText::new(tr(language, Text::TransferControls))
                        .size(10.0)
                        .strong()
                        .color(p.muted),
                );
                ui.add_space(7.0);
                ui.horizontal(|ui| {
                    ui.vertical(|ui| {
                        field_label(ui, Text::DividePackages);
                        ui.add(
                            egui::Slider::new(&mut self.draft.segments, 1..=16)
                                .suffix(tr(language, Text::PartsSuffix))
                                .show_value(true),
                        );
                    });
                    ui.add_space(26.0);
                    ui.vertical(|ui| {
                        field_label(ui, Text::Priority);
                        egui::ComboBox::from_id_salt("new_priority")
                            .selected_text(self.draft.priority.label(language))
                            .width(120.0)
                            .show_ui(ui, |ui| {
                                for choice in [Priority::Low, Priority::Normal, Priority::High] {
                                    ui.selectable_value(
                                        &mut self.draft.priority,
                                        choice,
                                        choice.label(language),
                                    );
                                }
                            });
                    });
                });
                ui.add_space(12.0);
                ui.horizontal(|ui| {
                    ui.checkbox(
                        &mut self.draft.unlimited_speed,
                        tr(language, Text::UnlimitedSpeed),
                    );
                    if !self.draft.unlimited_speed {
                        ui.label(tr(language, Text::MaxPerFile));
                        ui.add(
                            egui::DragValue::new(&mut self.draft.speed_limit_mb)
                                .range(0.1..=500.0)
                                .speed(0.2)
                                .suffix(" MB/s"),
                        );
                    }
                });
                ui.add_space(19.0);
                ui.horizontal(|ui| {
                    ui.label(
                        egui::RichText::new(tr(language, Text::RangeSupport))
                            .size(10.0)
                            .color(p.muted),
                    );
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui.button(tr(language, Text::Cancel)).clicked() {
                            request_close = true;
                        }
                        if ui
                            .add(
                                egui::Button::new(
                                    egui::RichText::new(tr(language, Text::StartDownload))
                                        .strong()
                                        .color(p.bg),
                                )
                                .fill(self.settings.accent.color_for(self.settings.theme)),
                            )
                            .clicked()
                        {
                            match self.manager.add(&self.draft, language) {
                                Ok(()) => {
                                    self.set_toast(tr(language, Text::AddedToQueue), false);
                                    self.draft = NewDownload::from_settings(&self.settings);
                                    request_close = true;
                                }
                                Err(error) => self.set_toast(
                                    tr(
                                        language,
                                        match error {
                                            AddError::InvalidUrl => Text::InvalidUrl,
                                            AddError::MissingFilename => Text::MissingFilename,
                                        },
                                    ),
                                    true,
                                ),
                            }
                        }
                    });
                });
            });
        self.show_new = keep_open && !request_close;
    }

    fn draw_toast(&mut self, ctx: &egui::Context) {
        let p = palette_from_context(ctx);
        if let Some((when, message, is_error)) = self.toast.clone() {
            if when.elapsed() < Duration::from_secs(3) {
                egui::Area::new(egui::Id::unique("hydra_toast"))
                    .anchor(egui::Align2::RIGHT_BOTTOM, egui::vec2(-20.0, -18.0))
                    .show(ctx, |ui| {
                        egui::Frame::new()
                            .fill(if is_error { p.failure } else { p.success })
                            .inner_margin(14)
                            .show(ui, |ui| {
                                ui.label(egui::RichText::new(message).size(12.0).color(p.text));
                            });
                    });
                ctx.request_repaint_after(Duration::from_millis(100));
            } else {
                self.toast = None;
            }
        }
    }
}

impl eframe::App for HydraApp {
    fn save(&mut self, storage: &mut dyn eframe::Storage) {
        eframe::set_value(storage, "hydra_preferences", &self.settings);
        eframe::set_value(storage, "hydra_downloads", &self.manager.snapshot());
    }

    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        let ctx = ui.ctx().clone();
        self.manager
            .launch_queued(&self.runtime, self.settings.max_concurrent.clamp(1, 6));
        self.draw_sidebar(ui);
        self.draw_main(ui);
        self.draw_new_dialog(&ctx);
        self.draw_toast(&ctx);
        ctx.request_repaint_after(Duration::from_millis(350));
    }
}

fn main() -> eframe::Result {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_inner_size([1200.0, 790.0])
            .with_min_inner_size([940.0, 620.0])
            .with_title("Hydra Manager"),
        ..Default::default()
    };
    eframe::run_native(
        "Hydra Manager",
        options,
        Box::new(|cc| Ok(Box::new(HydraApp::new(cc)))),
    )
}

async fn download(task: Arc<DownloadTask>) {
    let result = run_download(task.clone()).await;
    match result {
        Ok(()) => {
            task.speed.store(0, Ordering::Relaxed);
            if task.control.load(Ordering::Relaxed) != 2 {
                task.set_status(DownloadStatus::Completed);
            }
        }
        Err(error) => {
            task.speed.store(0, Ordering::Relaxed);
            if task.control.load(Ordering::Relaxed) == 2 {
                task.set_status(DownloadStatus::Cancelled);
            } else {
                *task.error.lock().unwrap_or_else(|e| e.into_inner()) = Some(error);
                task.set_status(DownloadStatus::Failed);
            }
        }
    }
}

async fn run_download(task: Arc<DownloadTask>) -> Result<(), String> {
    if let Some(parent) = task.path.parent() {
        fs::create_dir_all(parent)
            .await
            .map_err(|e| tr_arg(task.language, Text::FolderError, e))?;
    }
    let client = Client::builder()
        .user_agent("HydraManager/0.1.0")
        .build()
        .map_err(|e| tr_arg(task.language, Text::NetworkError, e))?;
    let head = client
        .head(&task.url)
        .header(ACCEPT_ENCODING, "identity")
        .send()
        .await
        .ok();
    let total = head
        .as_ref()
        .and_then(|response| {
            response
                .headers()
                .get(CONTENT_LENGTH)
                .and_then(|value| value.to_str().ok())
                .and_then(|value| value.parse::<u64>().ok())
        })
        .unwrap_or(0);
    let supports_ranges = head.as_ref().is_some_and(|response| {
        response
            .headers()
            .get(ACCEPT_RANGES)
            .and_then(|v| v.to_str().ok())
            .is_some_and(|v| v.eq_ignore_ascii_case("bytes"))
    });
    let segment_count = if supports_ranges && total > 0 {
        task.segments.min(total as usize).max(1)
    } else {
        1
    };
    task.effective_segments
        .store(segment_count as u8, Ordering::Relaxed);
    task.total.store(total, Ordering::Relaxed);

    if segment_count <= 1 {
        return download_single(&task, &client).await;
    }

    let file = OpenOptions::new()
        .create(true)
        .write(true)
        .truncate(true)
        .open(&task.path)
        .await
        .map_err(|e| tr_arg(task.language, Text::FileCreateError, e))?;
    file.set_len(total)
        .await
        .map_err(|e| tr_arg(task.language, Text::FilePrepareError, e))?;
    let file = Arc::new(AsyncMutex::new(file));
    let mut futures = Vec::with_capacity(segment_count);
    for index in 0..segment_count {
        let start = total * index as u64 / segment_count as u64;
        let end = total * (index + 1) as u64 / segment_count as u64 - 1;
        let client = client.clone();
        let file = file.clone();
        let task = task.clone();
        futures.push(async move {
            let response = client
                .get(&task.url)
                .header(ACCEPT_ENCODING, "identity")
                .header(RANGE, format!("bytes={start}-{end}"))
                .send()
                .await
                .map_err(|e| tr_arg(task.language, Text::NetworkError, e))?;
            if response.status() != StatusCode::PARTIAL_CONTENT {
                return Err(tr(task.language, Text::RangeRejected).to_owned());
            }
            let mut stream = response.bytes_stream();
            let mut offset = start;
            while let Some(item) = stream.next().await {
                wait_for_resume(&task).await?;
                let bytes = item.map_err(|e| tr_arg(task.language, Text::ReceiveError, e))?;
                task.limiter
                    .acquire(bytes.len(), task.speed_limit.load(Ordering::Relaxed))
                    .await;
                {
                    let mut output = file.lock().await;
                    output
                        .seek(std::io::SeekFrom::Start(offset))
                        .await
                        .map_err(|e| tr_arg(task.language, Text::WriteError, e))?;
                    output
                        .write_all(&bytes)
                        .await
                        .map_err(|e| tr_arg(task.language, Text::WriteError, e))?;
                }
                offset += bytes.len() as u64;
                task.record(bytes.len());
            }
            if offset != end + 1 {
                return Err(tr(task.language, Text::IncompleteSegment).to_owned());
            }
            Ok::<(), String>(())
        });
    }
    try_join_all(futures).await?;
    if task.progress.load(Ordering::Relaxed) != total {
        return Err(tr(task.language, Text::UnexpectedSize).into());
    }
    Ok(())
}

async fn download_single(task: &Arc<DownloadTask>, client: &Client) -> Result<(), String> {
    let response = client
        .get(&task.url)
        .header(ACCEPT_ENCODING, "identity")
        .send()
        .await
        .map_err(|e| tr_arg(task.language, Text::DownloadStartError, e))?;
    if !response.status().is_success() {
        return Err(tr_arg(
            task.language,
            Text::ServerResponse,
            response.status(),
        ));
    }
    let total = response.content_length().unwrap_or(0);
    task.total.store(total, Ordering::Relaxed);
    let mut output = OpenOptions::new()
        .create(true)
        .write(true)
        .truncate(true)
        .open(&task.path)
        .await
        .map_err(|e| tr_arg(task.language, Text::FileCreateError, e))?;
    let mut stream = response.bytes_stream();
    while let Some(item) = stream.next().await {
        wait_for_resume(task).await?;
        let bytes = item.map_err(|e| tr_arg(task.language, Text::ReceiveError, e))?;
        task.limiter
            .acquire(bytes.len(), task.speed_limit.load(Ordering::Relaxed))
            .await;
        output
            .write_all(&bytes)
            .await
            .map_err(|e| tr_arg(task.language, Text::WriteError, e))?;
        task.record(bytes.len());
    }
    output
        .flush()
        .await
        .map_err(|e| tr_arg(task.language, Text::WriteError, e))?;
    Ok(())
}

async fn wait_for_resume(task: &DownloadTask) -> Result<(), String> {
    loop {
        match task.control.load(Ordering::Relaxed) {
            2 => return Err(tr(task.language, Text::DownloadCancelled).into()),
            1 => sleep(Duration::from_millis(120)).await,
            _ => return Ok(()),
        }
    }
}

fn overview_card(
    ui: &mut egui::Ui,
    label: Text,
    value: String,
    caption: impl Into<String>,
    accent: egui::Color32,
    icon: IconKind,
) {
    let p = palette(ui);
    let language = language_from_context(ui.ctx());
    egui::Frame::new()
        .fill(p.panel)
        .stroke(egui::Stroke::new(1.0, p.line))
        .inner_margin(15)
        .show(ui, |ui| {
            ui.set_min_height(85.0);
            ui.horizontal(|ui| {
                ui.vertical(|ui| {
                    ui.label(
                        egui::RichText::new(tr(language, label))
                            .size(9.0)
                            .strong()
                            .color(p.muted),
                    );
                    ui.add_space(5.0);
                    ui.label(egui::RichText::new(value).size(24.0).strong().color(p.text));
                    ui.label(egui::RichText::new(caption).size(10.0).color(p.muted));
                });
                ui.with_layout(egui::Layout::right_to_left(egui::Align::TOP), |ui| {
                    egui::Frame::new()
                        .fill(egui::Color32::from_rgba_unmultiplied(
                            accent.r(),
                            accent.g(),
                            accent.b(),
                            28,
                        ))
                        .inner_margin(10)
                        .show(ui, |ui| {
                            draw_icon(ui, icon, 18.0, accent);
                        });
                });
            });
        });
}

fn status_pill(ui: &mut egui::Ui, status: DownloadStatus, accent: egui::Color32) {
    let p = palette(ui);
    let language = language_from_context(ui.ctx());
    let color = status.color(accent, p);
    egui::Frame::new()
        .fill(egui::Color32::from_rgba_unmultiplied(
            color.r(),
            color.g(),
            color.b(),
            28,
        ))
        .inner_margin(egui::Margin::symmetric(9, 5))
        .show(ui, |ui| {
            ui.label(
                egui::RichText::new(status.label(language))
                    .size(10.0)
                    .strong()
                    .color(color),
            );
        });
}

fn field_label(ui: &mut egui::Ui, label: Text) {
    let p = palette(ui);
    let language = language_from_context(ui.ctx());
    ui.label(
        egui::RichText::new(tr(language, label))
            .size(9.0)
            .strong()
            .color(p.muted),
    );
}

fn draw_hydra_mark(ui: &mut egui::Ui, size: f32, accent: egui::Color32) {
    let p = palette(ui);
    let (rect, _) = ui.allocate_exact_size(egui::vec2(size, size), egui::Sense::hover());
    let painter = ui.painter();
    painter.rect_filled(rect, 12.0, p.card_icon);
    let center = rect.center();
    let radius = size * 0.22;
    for angle in [-90.0_f32, 30.0, 150.0] {
        let radians = angle.to_radians();
        let point = center + egui::vec2(radians.cos() * size * 0.22, radians.sin() * size * 0.22);
        painter.line_segment([center, point], egui::Stroke::new(size * 0.075, accent));
        painter.circle_filled(point, radius * 0.47, accent);
    }
    painter.circle_filled(center, radius * 0.55, p.text);
}

fn settings_card(ui: &mut egui::Ui, title: Text, add_contents: impl FnOnce(&mut egui::Ui)) {
    let p = palette(ui);
    let language = language_from_context(ui.ctx());
    egui::Frame::new()
        .fill(p.panel)
        .stroke(egui::Stroke::new(1.0, p.line))
        .inner_margin(18)
        .show(ui, |ui| {
            ui.label(
                egui::RichText::new(tr(language, title))
                    .size(10.0)
                    .strong()
                    .color(p.muted),
            );
            ui.add_space(13.0);
            add_contents(ui);
        });
}

fn apply_appearance(ctx: &egui::Context, settings: &AppSettings) {
    let p = Palette::for_theme(settings.theme);
    let accent = settings.accent.color_for(settings.theme);
    ctx.data_mut(|data| data.insert_temp(egui::Id::unique("hydra_palette"), p));
    ctx.data_mut(|data| data.insert_temp(egui::Id::unique("hydra_language"), settings.language));
    ctx.set_theme(if settings.theme == UiTheme::Light {
        egui::Theme::Light
    } else {
        egui::Theme::Dark
    });
    let mut style = (*ctx.global_style()).clone();
    style.visuals.window_fill = p.panel;
    style.visuals.panel_fill = p.bg;
    style.visuals.extreme_bg_color = p.bg;
    style.visuals.faint_bg_color = p.panel_hi;
    style.visuals.override_text_color = Some(p.text);
    style.visuals.widgets.noninteractive.bg_fill = p.panel;
    style.visuals.widgets.inactive.bg_fill = p.panel_hi;
    style.visuals.widgets.hovered.bg_fill = p.selected;
    style.visuals.widgets.active.bg_fill = accent;
    style.visuals.selection.bg_fill = accent;
    style.spacing.item_spacing = if settings.compact_mode {
        egui::vec2(8.0, 6.0)
    } else {
        egui::vec2(10.0, 10.0)
    };
    style.spacing.button_padding = if settings.compact_mode {
        egui::vec2(6.0, 2.0)
    } else {
        egui::vec2(8.0, 4.0)
    };
    style.animation_time = if settings.animations {
        settings.animation_duration.clamp(0.12, 0.60)
    } else {
        0.0
    };
    ctx.set_global_style(style);
    ctx.set_zoom_factor(settings.ui_scale.clamp(0.85, 1.25));
}

fn draw_icon(ui: &mut egui::Ui, kind: IconKind, size: f32, color: egui::Color32) -> egui::Response {
    let (rect, response) = ui.allocate_exact_size(egui::vec2(size, size), egui::Sense::hover());
    paint_icon(ui.painter(), rect, kind, color);
    response
}

fn icon_button(ui: &mut egui::Ui, kind: IconKind, color: egui::Color32, tip: Text) -> bool {
    let p = palette(ui);
    let language = language_from_context(ui.ctx());
    let (rect, response) = ui.allocate_exact_size(egui::vec2(28.0, 28.0), egui::Sense::click());
    if response.hovered() {
        ui.painter().circle_filled(rect.center(), 13.0, p.panel_hi);
    }
    paint_icon(ui.painter(), rect.shrink(6.0), kind, color);
    response.on_hover_text(tr(language, tip)).clicked()
}

fn paint_icon(painter: &egui::Painter, rect: egui::Rect, kind: IconKind, color: egui::Color32) {
    let center = rect.center();
    let radius = rect.width().min(rect.height()) * 0.36;
    let stroke = egui::Stroke::new(1.7, color);
    let left = center.x - radius;
    let right = center.x + radius;
    let top = center.y - radius;
    let bottom = center.y + radius;
    let line = |a, b| painter.line_segment([a, b], stroke);

    match kind {
        IconKind::Files => {
            line(egui::pos2(left + 2.0, top), egui::pos2(right - 1.0, top));
            line(
                egui::pos2(right - 1.0, top),
                egui::pos2(right - 1.0, bottom - 2.0),
            );
            line(
                egui::pos2(right - 1.0, bottom - 2.0),
                egui::pos2(left + 2.0, bottom - 2.0),
            );
            line(
                egui::pos2(left + 2.0, bottom - 2.0),
                egui::pos2(left + 2.0, top),
            );
            line(egui::pos2(left, top + 3.0), egui::pos2(left, bottom));
            line(egui::pos2(left, bottom), egui::pos2(right - 3.0, bottom));
        }
        IconKind::Activity => {
            painter.circle_stroke(center, radius, stroke);
            line(
                egui::pos2(left + 2.0, center.y),
                egui::pos2(center.x - 2.0, center.y),
            );
            line(
                egui::pos2(center.x - 2.0, center.y),
                egui::pos2(center.x + 1.0, top + 2.0),
            );
            line(
                egui::pos2(center.x + 1.0, top + 2.0),
                egui::pos2(right - 2.0, bottom - 2.0),
            );
        }
        IconKind::Queue => {
            for offset in [-4.5, 0.0, 4.5] {
                line(
                    egui::pos2(left, center.y + offset),
                    egui::pos2(right, center.y + offset),
                );
            }
        }
        IconKind::Check => {
            line(
                egui::pos2(left, center.y),
                egui::pos2(center.x - 1.5, bottom),
            );
            line(egui::pos2(center.x - 1.5, bottom), egui::pos2(right, top));
        }
        IconKind::Settings => {
            painter.circle_stroke(center, radius * 0.42, stroke);
            for degrees in [0.0_f32, 45.0, 90.0, 135.0, 180.0, 225.0, 270.0, 315.0] {
                let angle = degrees.to_radians();
                let inner = center + egui::vec2(angle.cos(), angle.sin()) * radius * 0.62;
                let outer = center + egui::vec2(angle.cos(), angle.sin()) * radius;
                line(inner, outer);
            }
        }
        IconKind::Search => {
            painter.circle_stroke(center - egui::vec2(1.5, 1.5), radius * 0.68, stroke);
            line(
                center + egui::vec2(2.5, 2.5),
                egui::pos2(right + 1.0, bottom + 1.0),
            );
        }
        IconKind::Download => {
            line(
                egui::pos2(center.x, top),
                egui::pos2(center.x, center.y + 2.0),
            );
            line(
                egui::pos2(center.x, center.y + 2.0),
                egui::pos2(left + 1.0, center.y - 1.0),
            );
            line(
                egui::pos2(center.x, center.y + 2.0),
                egui::pos2(right - 1.0, center.y - 1.0),
            );
            line(
                egui::pos2(left, bottom - 1.0),
                egui::pos2(left, bottom + 2.0),
            );
            line(
                egui::pos2(left, bottom + 2.0),
                egui::pos2(right, bottom + 2.0),
            );
            line(
                egui::pos2(right, bottom + 2.0),
                egui::pos2(right, bottom - 1.0),
            );
        }
        IconKind::Pause => {
            painter.rect_filled(
                egui::Rect::from_center_size(
                    center - egui::vec2(2.5, 0.0),
                    egui::vec2(2.2, radius * 1.7),
                ),
                1,
                color,
            );
            painter.rect_filled(
                egui::Rect::from_center_size(
                    center + egui::vec2(2.5, 0.0),
                    egui::vec2(2.2, radius * 1.7),
                ),
                1,
                color,
            );
        }
        IconKind::Play => {
            let points = vec![
                egui::pos2(left + 1.0, top - 1.0),
                egui::pos2(right + 1.0, center.y),
                egui::pos2(left + 1.0, bottom + 1.0),
            ];
            painter.add(egui::Shape::convex_polygon(
                points,
                color,
                egui::Stroke::NONE,
            ));
        }
        IconKind::Close => {
            line(egui::pos2(left, top), egui::pos2(right, bottom));
            line(egui::pos2(right, top), egui::pos2(left, bottom));
        }
        IconKind::Retry => {
            painter.circle_stroke(center, radius * 0.78, stroke);
            line(
                egui::pos2(right - 2.0, top - 1.0),
                egui::pos2(right + 1.0, top + 2.0),
            );
            line(
                egui::pos2(right + 1.0, top + 2.0),
                egui::pos2(right - 3.0, top + 3.0),
            );
        }
        IconKind::Transfer => {
            line(
                egui::pos2(left, bottom - 1.0),
                egui::pos2(right - 1.0, top + 1.0),
            );
            line(
                egui::pos2(right - 1.0, top + 1.0),
                egui::pos2(right - 1.0, center.y),
            );
            line(
                egui::pos2(right - 1.0, top + 1.0),
                egui::pos2(center.x, top + 1.0),
            );
        }
        IconKind::Copy => {
            let size = radius * 1.35;
            let back = egui::Rect::from_center_size(
                center + egui::vec2(-2.0, 2.0),
                egui::vec2(size, size),
            );
            let front = egui::Rect::from_center_size(
                center + egui::vec2(2.0, -2.0),
                egui::vec2(size, size),
            );
            painter.rect_stroke(back, 1.0, stroke, egui::StrokeKind::Inside);
            painter.rect_stroke(front, 1.0, stroke, egui::StrokeKind::Inside);
        }
        IconKind::Reveal => {
            let folder_left = left;
            let folder_right = right;
            let folder_top = center.y + radius * 0.25;
            let folder_bottom = bottom;
            line(
                egui::pos2(folder_left, folder_top),
                egui::pos2(center.x - 2.0, folder_top),
            );
            line(
                egui::pos2(center.x - 2.0, folder_top),
                egui::pos2(center.x + 1.0, folder_top + 3.0),
            );
            line(
                egui::pos2(center.x + 1.0, folder_top + 3.0),
                egui::pos2(folder_right, folder_top + 3.0),
            );
            line(
                egui::pos2(folder_right, folder_top + 3.0),
                egui::pos2(folder_right, folder_bottom),
            );
            line(
                egui::pos2(folder_right, folder_bottom),
                egui::pos2(folder_left, folder_bottom),
            );
            line(
                egui::pos2(folder_left, folder_bottom),
                egui::pos2(folder_left, folder_top),
            );
        }
    }
}

fn suggested_filename(url: &str) -> String {
    let clean = url.split(['?', '#']).next().unwrap_or(url);
    clean
        .rsplit('/')
        .next()
        .filter(|part| !part.is_empty())
        .unwrap_or("download.bin")
        .to_owned()
}

fn safe_file_name(input: &str) -> String {
    let cleaned: String = input
        .trim()
        .chars()
        .map(|character| {
            if character == '/' || character == '\\' || character.is_control() {
                '_'
            } else {
                character
            }
        })
        .collect();
    if cleaned == "." || cleaned == ".." {
        "download.bin".into()
    } else {
        cleaned
    }
}

fn unique_path(directory: &Path, file_name: &str, reserved: &[Arc<DownloadTask>]) -> PathBuf {
    let original = directory.join(file_name);
    if !original.exists() && !reserved.iter().any(|task| task.path == original) {
        return original;
    }
    let path = Path::new(file_name);
    let stem = path
        .file_stem()
        .and_then(|x| x.to_str())
        .unwrap_or("download");
    let extension = path.extension().and_then(|x| x.to_str());
    for index in 2..10000 {
        let candidate = match extension {
            Some(extension) => directory.join(format!("{stem} ({index}).{extension}")),
            None => directory.join(format!("{stem} ({index})")),
        };
        if !candidate.exists() && !reserved.iter().any(|task| task.path == candidate) {
            return candidate;
        }
    }
    directory.join(format!("{stem}-{}", reserved.len() + 1))
}

fn path_parent(path: &Path, language: Language) -> String {
    path.parent()
        .and_then(Path::to_str)
        .unwrap_or(tr(language, Text::Destination))
        .to_owned()
}

fn format_bytes(bytes: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KB", "MB", "GB", "TB"];
    let mut size = bytes as f64;
    let mut unit = 0;
    while size >= 1024.0 && unit < UNITS.len() - 1 {
        size /= 1024.0;
        unit += 1;
    }
    if unit == 0 {
        format!("{size:.0} {}", UNITS[unit])
    } else {
        format!("{size:.1} {}", UNITS[unit])
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;

    #[derive(Default)]
    struct MemoryStorage(HashMap<String, String>);

    impl eframe::Storage for MemoryStorage {
        fn get_string(&self, key: &str) -> Option<String> {
            self.0.get(key).cloned()
        }

        fn set_string(&mut self, key: &str, value: String) {
            self.0.insert(key.to_owned(), value);
        }

        fn remove_string(&mut self, key: &str) {
            self.0.remove(key);
        }

        fn flush(&mut self) {}
    }

    #[test]
    fn app_save_restores_preferences_and_download_history() {
        let mut settings = AppSettings::default();
        settings.language = Language::French;
        settings.theme = UiTheme::Monochrome;
        settings.compact_mode = true;
        settings.animations = false;

        let directory = PathBuf::from("/tmp/hydra-manager-persistence-check");
        let mut manager = DownloadManager::new();
        manager
            .add(
                &NewDownload {
                    url: "https://example.com/finished.zip".into(),
                    file_name: "finished.zip".into(),
                    directory: directory.clone(),
                    segments: 4,
                    unlimited_speed: true,
                    speed_limit_mb: 8.0,
                    priority: Priority::High,
                },
                Language::Spanish,
            )
            .unwrap();
        let completed = &manager.tasks[0];
        completed.progress.store(2048, Ordering::Relaxed);
        completed.total.store(2048, Ordering::Relaxed);
        completed.set_status(DownloadStatus::Completed);

        manager
            .add(
                &NewDownload {
                    url: "https://example.com/in-progress.zip".into(),
                    file_name: "in-progress.zip".into(),
                    directory,
                    segments: 6,
                    unlimited_speed: false,
                    speed_limit_mb: 3.0,
                    priority: Priority::Normal,
                },
                Language::Spanish,
            )
            .unwrap();
        let interrupted = &manager.tasks[1];
        interrupted.progress.store(640, Ordering::Relaxed);
        interrupted.total.store(2048, Ordering::Relaxed);
        interrupted.set_status(DownloadStatus::Downloading);

        let mut app = HydraApp {
            manager,
            runtime: Runtime::new().unwrap(),
            settings,
            view: View::All,
            transition_started: Instant::now(),
            search: String::new(),
            show_new: false,
            draft: NewDownload::from_settings(&AppSettings::default()),
            toast: None,
        };
        let mut storage = MemoryStorage::default();
        eframe::App::save(&mut app, &mut storage);

        let restored_settings: AppSettings =
            eframe::get_value(&storage, "hydra_preferences").unwrap();
        let saved_downloads: Vec<PersistedDownload> =
            eframe::get_value(&storage, "hydra_downloads").unwrap();
        let restored = DownloadManager::restore(saved_downloads);

        assert_eq!(restored_settings.language, Language::French);
        assert_eq!(restored_settings.theme, UiTheme::Monochrome);
        assert!(restored_settings.compact_mode);
        assert!(!restored_settings.animations);
        assert_eq!(restored.tasks.len(), 2);
        assert_eq!(restored.tasks[0].status(), DownloadStatus::Completed);
        assert_eq!(restored.tasks[0].progress.load(Ordering::Relaxed), 2048);
        assert_eq!(restored.tasks[1].status(), DownloadStatus::Queued);
        assert_eq!(restored.tasks[1].progress.load(Ordering::Relaxed), 0);
        assert_eq!(restored.tasks[1].total.load(Ordering::Relaxed), 0);
        assert_eq!(restored.tasks[1].url, "https://example.com/in-progress.zip");
    }
}
