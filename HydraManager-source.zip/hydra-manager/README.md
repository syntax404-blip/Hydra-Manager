# Hydra Manager

Hydra Manager es un gestor de descargas de escritorio escrito en Rust para macOS. Usa una interfaz nativa de escritorio basada en egui y un motor HTTP asíncrono.

## Funciones

- Descargas HTTP y HTTPS.
- Descarga por segmentos HTTP Range, de 1 a 16 partes.
- Descarga automática en una sola conexión si el servidor no admite segmentos.
- Prioridad baja, normal y alta.
- La cola inicia primero las tareas de prioridad alta.
- Límite de velocidad por descarga y opción sin límite.
- Entre 1 y 6 transferencias simultáneas.
- Pausar una transferencia.
- Reanudar una transferencia pausada.
- Cancelar transferencias.
- Reintentar descargas fallidas o canceladas.
- Elegir el nombre del archivo.
- Elegir la carpeta para cada descarga.
- Configurar carpeta predeterminada.
- Evitar sobrescrituras mediante nombres únicos.
- Ver todas las descargas.
- Filtrar transferencias activas.
- Filtrar la cola.
- Ver descargas finalizadas y fallidas.
- Buscar por nombre de archivo.
- Consultar porcentaje y bytes transferidos.
- Consultar velocidad por archivo y velocidad total.
- Guardar el historial, la cola y las preferencias localmente.
- Restaurar la cola y el historial al abrir la app.
- Pegar enlaces con `⌘V`.
- Copiar el enlace de una tarea.
- Mostrar el archivo en Finder.
- Temas oscuro, claro y blanco y negro.
- Elegir entre cuatro colores de acento.
- Ajustar la escala de la interfaz.
- Activar el modo compacto.
- Activar o desactivar las animaciones y ajustar su duración.
- Elegir entre español, inglés, alemán, francés, catalán y ruso.
- Configurar valores predeterminados de segmentos, prioridad, velocidad y concurrencia.
- Iconos vectoriales y marca propia para macOS.

## Compilar y abrir en macOS

Requisitos: Rust instalado desde rustup, los destinos `aarch64-apple-darwin` y `x86_64-apple-darwin`, y Xcode Command Line Tools. La primera compilación descarga dependencias de crates.io y crea una app universal para Apple Silicon e Intel.

```sh
./scripts/build_macos.sh
open "outputs/Hydra Manager.app"
```

Para elegir otro destino de compilación, define `HYDRA_OUTPUT_DIR` al ejecutar el script.

También se puede ejecutar en modo desarrollo desde esta carpeta con `cargo run`.

## Notas de esta versión

- Las descargas terminadas, fallidas y en cola conservan su estado. Si se cierra la app durante una transferencia, al abrirla volverá a la cola y empezará de cero; todavía no se guarda el archivo parcial para reanudarlo byte por byte.
- Los controles de segmento dependen de que el servidor responda a `HEAD` con `Accept-Ranges: bytes` y acepte solicitudes `Range`.
- Algunas URLs requieren cabeceras, cookies o autenticación que esta versión todavía no permite configurar.
