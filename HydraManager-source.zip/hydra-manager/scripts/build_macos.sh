#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="${HYDRA_OUTPUT_DIR:-$PROJECT_DIR/outputs}"
APP_DIR="$OUTPUT_DIR/Hydra Manager.app"

cd "$PROJECT_DIR"
export MACOSX_DEPLOYMENT_TARGET="${MACOSX_DEPLOYMENT_TARGET:-12.0}"
cargo build --release --target aarch64-apple-darwin
cargo build --release --target x86_64-apple-darwin
lipo -create \
	"$PROJECT_DIR/target/aarch64-apple-darwin/release/hydra-manager" \
	"$PROJECT_DIR/target/x86_64-apple-darwin/release/hydra-manager" \
	-output "$PROJECT_DIR/target/hydra-manager-universal"

mkdir -p "$OUTPUT_DIR"
rm -rf "$APP_DIR"
mkdir -p "$APP_DIR/Contents/MacOS"
cp "$PROJECT_DIR/target/hydra-manager-universal" "$APP_DIR/Contents/MacOS/Hydra Manager"
cp "$PROJECT_DIR/Info.plist" "$APP_DIR/Contents/Info.plist"
mkdir -p "$APP_DIR/Contents/Resources"
cp "$PROJECT_DIR/assets/hydra.icns" "$APP_DIR/Contents/Resources/Hydra.icns"
chmod +x "$APP_DIR/Contents/MacOS/Hydra Manager"
codesign --force --deep --sign - "$APP_DIR"
printf 'Created %s\n' "$APP_DIR"
